﻿namespace Smart_Mover
{
    partial class Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Menu));
            this.exitbtn = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.Menulbl = new System.Windows.Forms.Label();
            this.lgoutbtn = new System.Windows.Forms.Button();
            this.btncustomer = new System.Windows.Forms.Button();
            this.btnproduct = new System.Windows.Forms.Button();
            this.btnload = new System.Windows.Forms.Button();
            this.btntransport = new System.Windows.Forms.Button();
            this.btnjob = new System.Windows.Forms.Button();
            this.btndepot = new System.Windows.Forms.Button();
            this.btnpayment = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.datelbl = new System.Windows.Forms.Label();
            this.tymlbl = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.btnrecrds = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // exitbtn
            // 
            this.exitbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.exitbtn.Font = new System.Drawing.Font("Trebuchet MS", 18F, System.Drawing.FontStyle.Bold);
            this.exitbtn.ForeColor = System.Drawing.Color.White;
            this.exitbtn.Location = new System.Drawing.Point(59, 15);
            this.exitbtn.Name = "exitbtn";
            this.exitbtn.Size = new System.Drawing.Size(62, 52);
            this.exitbtn.TabIndex = 10;
            this.exitbtn.Text = "x";
            this.exitbtn.UseVisualStyleBackColor = false;
            this.exitbtn.Click += new System.EventHandler(this.exitbtn_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.panel2.Controls.Add(this.button1);
            this.panel2.Controls.Add(this.exitbtn);
            this.panel2.Location = new System.Drawing.Point(1161, -4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(122, 769);
            this.panel2.TabIndex = 20;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.button1.Font = new System.Drawing.Font("Cooper Black", 10.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(2, 15);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(62, 52);
            this.button1.TabIndex = 9;
            this.button1.Text = "__";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(45)))), ((int)(((byte)(45)))));
            this.panel1.Controls.Add(this.Menulbl);
            this.panel1.Controls.Add(this.lgoutbtn);
            this.panel1.Location = new System.Drawing.Point(0, -4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1283, 106);
            this.panel1.TabIndex = 15;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // Menulbl
            // 
            this.Menulbl.AutoSize = true;
            this.Menulbl.BackColor = System.Drawing.Color.Transparent;
            this.Menulbl.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Menulbl.Font = new System.Drawing.Font("High Tower Text", 36F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Menulbl.ForeColor = System.Drawing.Color.Transparent;
            this.Menulbl.Location = new System.Drawing.Point(586, 13);
            this.Menulbl.Name = "Menulbl";
            this.Menulbl.Size = new System.Drawing.Size(169, 71);
            this.Menulbl.TabIndex = 9;
            this.Menulbl.Text = "Menu";
            // 
            // lgoutbtn
            // 
            this.lgoutbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(45)))), ((int)(((byte)(45)))));
            this.lgoutbtn.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lgoutbtn.ForeColor = System.Drawing.Color.White;
            this.lgoutbtn.Location = new System.Drawing.Point(12, 29);
            this.lgoutbtn.Name = "lgoutbtn";
            this.lgoutbtn.Size = new System.Drawing.Size(89, 52);
            this.lgoutbtn.TabIndex = 8;
            this.lgoutbtn.Text = "Logout";
            this.lgoutbtn.UseVisualStyleBackColor = false;
            this.lgoutbtn.Click += new System.EventHandler(this.hmbtn_Click);
            // 
            // btncustomer
            // 
            this.btncustomer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.btncustomer.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btncustomer.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncustomer.ForeColor = System.Drawing.Color.White;
            this.btncustomer.Location = new System.Drawing.Point(0, 102);
            this.btncustomer.Name = "btncustomer";
            this.btncustomer.Size = new System.Drawing.Size(321, 85);
            this.btncustomer.TabIndex = 1;
            this.btncustomer.Text = "Customer";
            this.btncustomer.UseVisualStyleBackColor = false;
            this.btncustomer.Click += new System.EventHandler(this.btncustomer_Click);
            // 
            // btnproduct
            // 
            this.btnproduct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.btnproduct.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnproduct.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnproduct.ForeColor = System.Drawing.Color.White;
            this.btnproduct.Location = new System.Drawing.Point(0, 184);
            this.btnproduct.Name = "btnproduct";
            this.btnproduct.Size = new System.Drawing.Size(321, 85);
            this.btnproduct.TabIndex = 2;
            this.btnproduct.Text = "Product";
            this.btnproduct.UseVisualStyleBackColor = false;
            this.btnproduct.Click += new System.EventHandler(this.btnproduct_Click);
            // 
            // btnload
            // 
            this.btnload.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.btnload.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnload.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnload.ForeColor = System.Drawing.Color.White;
            this.btnload.Location = new System.Drawing.Point(0, 266);
            this.btnload.Name = "btnload";
            this.btnload.Size = new System.Drawing.Size(321, 85);
            this.btnload.TabIndex = 3;
            this.btnload.Text = "Load";
            this.btnload.UseVisualStyleBackColor = false;
            this.btnload.Click += new System.EventHandler(this.btnload_Click);
            // 
            // btntransport
            // 
            this.btntransport.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.btntransport.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btntransport.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btntransport.ForeColor = System.Drawing.Color.White;
            this.btntransport.Location = new System.Drawing.Point(0, 430);
            this.btntransport.Name = "btntransport";
            this.btntransport.Size = new System.Drawing.Size(321, 85);
            this.btntransport.TabIndex = 6;
            this.btntransport.Text = "Transport";
            this.btntransport.UseVisualStyleBackColor = false;
            this.btntransport.Click += new System.EventHandler(this.btntransport_Click_1);
            // 
            // btnjob
            // 
            this.btnjob.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.btnjob.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnjob.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnjob.ForeColor = System.Drawing.Color.White;
            this.btnjob.Location = new System.Drawing.Point(0, 508);
            this.btnjob.Name = "btnjob";
            this.btnjob.Size = new System.Drawing.Size(321, 85);
            this.btnjob.TabIndex = 4;
            this.btnjob.Text = "Job";
            this.btnjob.UseVisualStyleBackColor = false;
            this.btnjob.Click += new System.EventHandler(this.btnjob_Click);
            // 
            // btndepot
            // 
            this.btndepot.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.btndepot.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btndepot.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndepot.ForeColor = System.Drawing.Color.White;
            this.btndepot.Location = new System.Drawing.Point(0, 347);
            this.btndepot.Name = "btndepot";
            this.btndepot.Size = new System.Drawing.Size(321, 85);
            this.btndepot.TabIndex = 5;
            this.btndepot.Text = "Depot";
            this.btndepot.UseVisualStyleBackColor = false;
            this.btndepot.Click += new System.EventHandler(this.btndepot_Click);
            // 
            // btnpayment
            // 
            this.btnpayment.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.btnpayment.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnpayment.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnpayment.ForeColor = System.Drawing.Color.White;
            this.btnpayment.Location = new System.Drawing.Point(0, 592);
            this.btnpayment.Name = "btnpayment";
            this.btnpayment.Size = new System.Drawing.Size(321, 85);
            this.btnpayment.TabIndex = 7;
            this.btnpayment.Text = "Payments";
            this.btnpayment.UseVisualStyleBackColor = false;
            this.btnpayment.Click += new System.EventHandler(this.btnpayment_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.panel3.Controls.Add(this.datelbl);
            this.panel3.Controls.Add(this.tymlbl);
            this.panel3.Location = new System.Drawing.Point(321, 674);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(841, 88);
            this.panel3.TabIndex = 8;
            // 
            // datelbl
            // 
            this.datelbl.AutoSize = true;
            this.datelbl.Font = new System.Drawing.Font("Trebuchet MS", 13.8F, System.Drawing.FontStyle.Bold);
            this.datelbl.ForeColor = System.Drawing.Color.DimGray;
            this.datelbl.Location = new System.Drawing.Point(488, 37);
            this.datelbl.Name = "datelbl";
            this.datelbl.Size = new System.Drawing.Size(65, 29);
            this.datelbl.TabIndex = 83;
            this.datelbl.Text = "Date";
            // 
            // tymlbl
            // 
            this.tymlbl.AutoSize = true;
            this.tymlbl.Font = new System.Drawing.Font("Trebuchet MS", 13.8F, System.Drawing.FontStyle.Bold);
            this.tymlbl.ForeColor = System.Drawing.Color.DimGray;
            this.tymlbl.Location = new System.Drawing.Point(282, 37);
            this.tymlbl.Name = "tymlbl";
            this.tymlbl.Size = new System.Drawing.Size(69, 29);
            this.tymlbl.TabIndex = 82;
            this.tymlbl.Text = "Time";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // btnrecrds
            // 
            this.btnrecrds.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.btnrecrds.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnrecrds.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnrecrds.ForeColor = System.Drawing.Color.White;
            this.btnrecrds.Location = new System.Drawing.Point(0, 676);
            this.btnrecrds.Name = "btnrecrds";
            this.btnrecrds.Size = new System.Drawing.Size(321, 85);
            this.btnrecrds.TabIndex = 21;
            this.btnrecrds.Text = "Records";
            this.btnrecrds.UseVisualStyleBackColor = false;
            this.btnrecrds.Click += new System.EventHandler(this.btnrecrds_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(66, 72);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(632, 380);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 22;
            this.pictureBox2.TabStop = false;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(25)))), ((int)(((byte)(30)))));
            this.panel4.Controls.Add(this.pictureBox2);
            this.panel4.Location = new System.Drawing.Point(357, 129);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(774, 513);
            this.panel4.TabIndex = 23;
            // 
            // Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1282, 760);
            this.ControlBox = false;
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.btnrecrds);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.btnpayment);
            this.Controls.Add(this.btndepot);
            this.Controls.Add(this.btnjob);
            this.Controls.Add(this.btntransport);
            this.Controls.Add(this.btnload);
            this.Controls.Add(this.btnproduct);
            this.Controls.Add(this.btncustomer);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.ForeColor = System.Drawing.SystemColors.AppWorkspace;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximumSize = new System.Drawing.Size(1300, 807);
            this.Name = "Menu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Menu";
            this.Load += new System.EventHandler(this.Menu_Load);
            this.panel2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel4.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button exitbtn;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button lgoutbtn;
        private System.Windows.Forms.Button btncustomer;
        private System.Windows.Forms.Button btnproduct;
        private System.Windows.Forms.Button btnload;
        private System.Windows.Forms.Button btntransport;
        private System.Windows.Forms.Button btnjob;
        private System.Windows.Forms.Button btndepot;
        private System.Windows.Forms.Button btnpayment;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label Menulbl;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label datelbl;
        private System.Windows.Forms.Label tymlbl;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button btnrecrds;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel panel4;
    }
}