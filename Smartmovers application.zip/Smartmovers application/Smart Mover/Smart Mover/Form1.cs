﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Smart_Mover
{
    public partial class login : Form
    {
        public login()
        {
            InitializeComponent();
        }

        private void exitbtn_Click(object sender, EventArgs e)
        {
            DialogResult dialogresult = MessageBox.Show("Are Your Going to exit?", "Exit Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Error);
            if (dialogresult == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
        string Username, Password;
        private void loginbtn_Click(object sender, EventArgs e)
        {
            Username = usrnametxtbx.Text;
            Password = passwrdtxtbx.Text;

            if (Username == "User" && Password == "a1b2c3")
            {
                MessageBox.Show("Accessing Granted","Login");
                progressBar1.Visible = true;
                timer1.Start();
            }
            else
            {
                MessageBox.Show("Invalid username or password", "Configuration", MessageBoxButtons.OK, MessageBoxIcon.Error);

                usrnametxtbx.Clear();
                passwrdtxtbx.Clear();
            }
        }

        private void login_Load(object sender, EventArgs e)
        {
            progressBar1.Visible = false;

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (progressBar1.Value < 100)
            {
                progressBar1.Value = progressBar1.Value + 10;

            }
            else
            {
                timer1.Enabled = false;
                Menu f2 = new Menu();
                f2.Show();
                this.Hide();
            }
        }

        private void passwordchckbx_CheckedChanged(object sender, EventArgs e)
        {
            if (passwordchckbx.Checked == true)
            {
                passwrdtxtbx.PasswordChar = '\0';
            }
            if (passwordchckbx.Checked == false)
            {
                passwrdtxtbx.PasswordChar = '*';
            }
        }

        private void usrnametxtbx_Click(object sender, EventArgs e)
        {
            namelbl.ForeColor = Color.White;
            pictureBox2.Visible = false;
            panel3.BackColor = Color.White;

        }

        private void passwrdtxtbx_Click(object sender, EventArgs e)
        {
            passwrdlbl.ForeColor = Color.White;
            pictureBox4.Visible = false;
            panel5.BackColor = Color.White;
        }

        private void progressBar1_Click(object sender, EventArgs e)
        {

        }

        private void usrnametxtbx_TabIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult dialogresult = MessageBox.Show("Are Your Sure?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Error);
            if (dialogresult == DialogResult.Yes)
            {
                front f11 = new front();
                f11.Show();
                this.Hide();
            }
        }
        
    }
}
