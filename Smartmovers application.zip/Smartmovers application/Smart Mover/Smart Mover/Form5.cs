﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Smart_Mover
{
    public partial class Load : Form
    {
        public Load()
        {
            InitializeComponent();
            filldata();
            fillcombobox();
        }
        static string connection = @"Data Source=ABI\SQLEXPRESS;Initial Catalog=SmartMovers;Integrated Security=True";
        SqlConnection con = new SqlConnection(connection);
        string type, loadid, productid;
        private void exitbtn_Click(object sender, EventArgs e)
        {
            DialogResult dialogresult = MessageBox.Show("Are Your Going to exit?", "Exit Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Error);
            if (dialogresult == DialogResult.Yes)
            {
                Application.Exit();
            }

        }

        private void hmbtn_Click(object sender, EventArgs e)
        {
            DialogResult dialogresult = MessageBox.Show("Are Your Sure?", "Configuration", MessageBoxButtons.YesNo, MessageBoxIcon.Error);
            if (dialogresult == DialogResult.Yes)
            {
                Menu f2 = new Menu();
                f2.Show();
                this.Hide();
            }
        }

        private void exitbtn_Click_1(object sender, EventArgs e)
        {
            DialogResult dialogresult = MessageBox.Show("Are Your Going to exit?", "Exit Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Error);
            if (dialogresult == DialogResult.Yes)
            {
                Application.Exit();
            }

        }

        private void Form5_Load(object sender, EventArgs e)
        {
            timer1.Start();
            tymlbl.Text = DateTime.Now.ToLongTimeString();
            datelbl.Text = DateTime.Now.ToLongDateString();
            prdctcombobx.ResetText();

        }

        private void datelbl_Click(object sender, EventArgs e)
        {

        }

        private void tymlbl_Click(object sender, EventArgs e)
        {

        }

        private void Nxtbtn_Click(object sender, EventArgs e)
        {
            Depot f7 = new Depot();
            f7.Show();
            this.Hide();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Start();
            tymlbl.Text = DateTime.Now.ToLongTimeString();
        }

        private void minimizebtn_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void Savebtn_Click(object sender, EventArgs e)
        {
            if (ldidtbxtxbx.Text == "" || typecombobx.Text == "" || prdctcombobx.Text == "" )
            {
                MessageBox.Show("Please fill the all blanks", "Alert");
            }
            else
            {

                loadid = ldidtbxtxbx.Text;
                type = typecombobx.Text;
                productid = prdctcombobx.Text;
      

                con.Open();
                string insert = "insert into Load values ('" + loadid + "','" + type + "','" + productid + "')";
                SqlCommand cmd = new SqlCommand(insert, con);
                cmd.ExecuteNonQuery();

                con.Close();

                MessageBox.Show("successfully saved in Load database", "Message");
            }
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            if (ldidtbxtxbx.Text == "" || typecombobx.Text == "" || prdctcombobx.Text == "" )
            {
                MessageBox.Show("Please fill the all blanks", "Alert");
            }
            else
            {

                loadid = ldidtbxtxbx.Text;
                type = typecombobx.Text;
                productid = prdctcombobx.Text;
      
                string update = "update Load set Type='" + type + "',Product_id='" + productid + "' where Load_id ='" + loadid + "'";
                if (MessageBox.Show("Are you going to update the Load data?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                {
                    return;
                }
                else
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand(update, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Succesfully updated", "Message");
                    con.Close();

                }
            }
        }

        private void btnsearch_Click(object sender, EventArgs e)
        {
            if (ldidtbxtxbx.Text == "")
            {
                MessageBox.Show("Please fill the ID", "Alert");
            }
            else
            {
                loadid = ldidtbxtxbx.Text;
                string search = "Select *from Load  where Load_id='" + loadid + "'";
                SqlCommand cmd = new SqlCommand(search, con);
                con.Open();
                SqlDataReader r = cmd.ExecuteReader();

                if (r.Read())
                {
                    typecombobx.Text = r["Type"].ToString();
                    prdctcombobx.Text = r["Product_id"].ToString();
                    con.Close();
                }
                else
                {
                    MessageBox.Show("Invalid ID", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }

            }
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            if (ldidtbxtxbx.Text == "")
            {
                MessageBox.Show("Please fill the ID", "Alert");
            }
            else
            {
                loadid = ldidtbxtxbx.Text;
                con.Open();
                string delete = "delete from Load where Load_id='" + loadid + "'";
                if (MessageBox.Show("Are you sure to delete data?", "confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                {
                    return;
                }
                else
                {
                    SqlCommand cmd = new SqlCommand(delete, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Successfully Deleted", "Message");
                }
                con.Close();
            }
        }

        private void Clearbtn_Click(object sender, EventArgs e)
        {
            ldidtbxtxbx.Clear();
            typecombobx.ResetText();
            prdctcombobx.ResetText();

        }
        private void filldata()
        {
            con.Open();

            SqlDataAdapter dtadpt = new SqlDataAdapter("select * from Load", con);
            DataTable dttbl = new DataTable();
            dtadpt.Fill(dttbl);
            dataGridView1.DataSource = dttbl;

            con.Close();
        }

        private void dataGridView1_DoubleClick(object sender, EventArgs e)
        {
            ldidtbxtxbx.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            typecombobx.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            prdctcombobx.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
     
  }

        private void prdctcombobx_SelectedIndexChanged(object sender, EventArgs e)
        {


        }
        private void fillcombobox()
        {
            SqlDataAdapter da = new SqlDataAdapter("Select  Product_id from Product order by Product_id desc", con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            prdctcombobx.DataSource = dt;
            prdctcombobx.DisplayMember = "Product_id";
            prdctcombobx.ValueMember = "Product_id";

        }

        private void btnrefresh_Click(object sender, EventArgs e)
        {
            filldata();
        }
    }
}

