﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Smart_Mover
{
    public partial class Transport : Form
    {
        public Transport()
        {
            InitializeComponent();
            filldata();
            fillcombobox1();

        }
        static string connection = @"Data Source=ABI\SQLEXPRESS;Initial Catalog=SmartMovers;Integrated Security=True";
        string transid,driver,assitnt,lorry,depotid,container;
        SqlConnection con = new SqlConnection(connection);
        private void hmbtn_Click(object sender, EventArgs e)
        {
            DialogResult dialogresult = MessageBox.Show("Are Your Sure?", "Configuration", MessageBoxButtons.YesNo, MessageBoxIcon.Error);
            if (dialogresult == DialogResult.Yes)
            {
                Menu f2 = new Menu();
                f2.Show();
                this.Hide();
            }
        }

        private void minimizebtn_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void exitbtn_Click(object sender, EventArgs e)
        {
            DialogResult dialogresult = MessageBox.Show("Are Your Going to exit?", "Exit Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Error);
            if (dialogresult == DialogResult.Yes)
            {
                Application.Exit();
            }

        }

        private void Form8_Load(object sender, EventArgs e)
        {
            timer1.Start();
            tymlbl.Text = DateTime.Now.ToLongTimeString();
            datelbl.Text = DateTime.Now.ToLongDateString();
            depotcmbbx.ResetText();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Start();
            tymlbl.Text = DateTime.Now.ToLongTimeString();
        }

        private void Nxtbtn_Click(object sender, EventArgs e)
        {
            Job f6 = new Job();
            f6.Show();
            this.Hide();
        }
        private void filldata()
        {
            con.Open();

            SqlDataAdapter dtadpt = new SqlDataAdapter("select * from Transport", con);
            DataTable dttbl = new DataTable();
            dtadpt.Fill(dttbl);
            dataGridView1.DataSource = dttbl;

            con.Close();
        }
        private void fillcombobox1()
        {

            SqlDataAdapter dq = new SqlDataAdapter("Select Depot_id from Depot order by Depot_id desc", con);
            DataTable dc = new DataTable();
            dq.Fill(dc);
            depotcmbbx.DataSource = dc;
            depotcmbbx.DisplayMember = "Depot_id";
            depotcmbbx.ValueMember = "Depot_id";


        }

        private void Savebtn_Click(object sender, EventArgs e)
        {
           if (transportidtxtbxtxbx.Text == "" || drvrtrxtbx.Text ==""||assttnttxtbx.Text == "" ||
            cmbcontainer.Text==""||depotcmbbx.Text == "")
            {
                MessageBox.Show("Please fill the all blanks","Alert");
            }
            else
            {

                transid = transportidtxtbxtxbx.Text;
                driver = drvrtrxtbx.Text;
                assitnt = assttnttxtbx.Text;
                lorry = lorrycmbbx.Text;
                container = cmbcontainer.Text;

                depotid = depotcmbbx.Text;

                con.Open();
                string insert = "insert into Transport values ('" + transid + "','" + driver + "','" + assitnt + "','"+  lorry +"','" +
                container+"','" + depotid + "')";
                SqlCommand cmd = new SqlCommand(insert, con);
                cmd.ExecuteNonQuery();

                con.Close();

                MessageBox.Show("successfully saved in Transport database","Message");
            }
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {         
            if (transportidtxtbxtxbx.Text == "" || drvrtrxtbx.Text ==""||assttnttxtbx.Text == ""  ||
            cmbcontainer.Text==""|| depotcmbbx.Text == "")
            {
                MessageBox.Show("Please fill the all blanks","Alert");
            }
            else
            {

                transid = transportidtxtbxtxbx.Text;
                driver = drvrtrxtbx.Text;
                assitnt = assttnttxtbx.Text;
                lorry = lorrycmbbx.Text;
                container = cmbcontainer.Text;
                depotid = depotcmbbx.Text;
            
                    string update = "update Transport set Driver ='" + driver + "',Assistant='" + assitnt + "',Lorry='" +
                    lorry + "',Container='"+ container +"',Depot_id='" + depotid + "' where Transport_id ='" + transid + "'";
                if (MessageBox.Show("Are you going to update the Transport data?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                {
                    return;
                }
                else
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand(update, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Succesfully updated","Message");
                    con.Close();

                }

        
            }
        }

        private void btnsearch_Click(object sender, EventArgs e)
        {
            if (transportidtxtbxtxbx.Text == "")
            {
                MessageBox.Show("Please fill the ID", "Alert");
            }
            else
            {
                transid = transportidtxtbxtxbx.Text;
                string search = "Select *from Transport where Transport_id='" + transid + "'";
                SqlCommand cmd = new SqlCommand(search, con);

                con.Open();
                SqlDataReader r = cmd.ExecuteReader();
                if (r.Read())
                {
                drvrtrxtbx.Text = r["Driver"].ToString();
                assttnttxtbx.Text = r["Assistant"].ToString();
                lorrycmbbx.Text = r["Lorry"].ToString();
                cmbcontainer.Text=r["Container"].ToString();
                depotcmbbx.Text = r["Depot_id"].ToString();

                    con.Close();
                }
                else
                {
                    MessageBox.Show("Invalid ID", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
        }
    }

        private void btndelete_Click(object sender, EventArgs e)
        {
            if (transportidtxtbxtxbx.Text == "")
            {
                MessageBox.Show("Please fill the ID", "Alert");
            }
            else
            {
                transid = transportidtxtbxtxbx.Text;
                con.Open();
                string delete = "delete from Transport where Transport_id ='" + transid + "'";
                if (MessageBox.Show("Are you sure to delete data?", "confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                {
                    return;
                }
                else
                {
                    SqlCommand cmd = new SqlCommand(delete, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Successfully Deleted", "Message");
                }
                con.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
             transportidtxtbxtxbx.Clear();
             drvrtrxtbx.Clear();
             assttnttxtbx.Clear();
             lorrycmbbx.ResetText();
             cmbcontainer.ResetText();
             depotcmbbx.ResetText();
        }

        private void dataGridView1_DoubleClick(object sender, EventArgs e)
        {
            transportidtxtbxtxbx.Text= dataGridView1.CurrentRow.Cells[0].Value.ToString();
            drvrtrxtbx.Text= dataGridView1.CurrentRow.Cells[1].Value.ToString();
            assttnttxtbx.Text= dataGridView1.CurrentRow.Cells[2].Value.ToString();
            lorrycmbbx.SelectedText= dataGridView1.CurrentRow.Cells[3].Value.ToString();
            cmbcontainer.SelectedText = dataGridView1.CurrentRow.Cells[4].Value.ToString();
            depotcmbbx.SelectedText= dataGridView1.CurrentRow.Cells[5].Value.ToString();

        }

        private void btnrefresh_Click(object sender, EventArgs e)
        {
            filldata();
        }
    }
}