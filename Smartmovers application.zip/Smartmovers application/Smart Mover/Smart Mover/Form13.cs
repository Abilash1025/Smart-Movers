﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Smart_Mover
{
    public partial class userrecord : Form
    {
        public userrecord()
        {
            InitializeComponent();
        }
        static string connection = @"Data Source=ABI\SQLEXPRESS;Initial Catalog=SmartMovers;Integrated Security=True";
        SqlConnection con = new SqlConnection(connection);
        private void btncustomer_Click(object sender, EventArgs e)
        {
            con.Open();

            SqlDataAdapter dtadpt = new SqlDataAdapter("select * from Customer", con);
            DataTable dttbl = new DataTable();
            dtadpt.Fill(dttbl);
            dataGridView1.DataSource = dttbl;

            con.Close();
        }

        private void btnproduct_Click(object sender, EventArgs e)
        {
            con.Open();

            SqlDataAdapter dtadpt = new SqlDataAdapter("select * from Product", con);
            DataTable dttbl = new DataTable();
            dtadpt.Fill(dttbl);
            dataGridView1.DataSource = dttbl;

            con.Close();
        }

        private void btnload_Click(object sender, EventArgs e)
        {
            con.Open();

            SqlDataAdapter dtadpts = new SqlDataAdapter("select * from Load", con);
            DataTable dttb = new DataTable();
            dtadpts.Fill(dttb);
            dataGridView1.DataSource = dttb;

            con.Close();
        }

        private void btnjob_Click(object sender, EventArgs e)
        {
            con.Open();

            SqlDataAdapter dtadpt = new SqlDataAdapter("select * from Job", con);
            DataTable dttbla = new DataTable();
            dtadpt.Fill(dttbla);
            dataGridView1.DataSource = dttbla;

            con.Close();
        }

        private void btndepot_Click(object sender, EventArgs e)
        {
            con.Open();

            SqlDataAdapter dtadpt = new SqlDataAdapter("select * from Depot", con);
            DataTable dttblx = new DataTable();
            dtadpt.Fill(dttblx);
            dataGridView1.DataSource = dttblx;

            con.Close();
        }

        private void btntransport_Click(object sender, EventArgs e)
        {
            con.Open();

            SqlDataAdapter dtadpt = new SqlDataAdapter("select * from Transport", con);
            DataTable dttblc = new DataTable();
            dtadpt.Fill(dttblc);
            dataGridView1.DataSource = dttblc;

            con.Close();
        }

        private void btnpayment_Click(object sender, EventArgs e)
        {
            con.Open();

            SqlDataAdapter dtadpt = new SqlDataAdapter("select * from Payment", con);
            DataTable dttblv= new DataTable();
            dtadpt.Fill(dttblv);
            dataGridView1.DataSource = dttblv;

            con.Close();
        }

        private void exitbtn_Click(object sender, EventArgs e)
        {
            DialogResult dialogresult = MessageBox.Show("Are Your Going to exit?", "Exit Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Error);
            if (dialogresult == DialogResult.Yes)
            {
                Application.Exit();
            }

        }

        private void minimzebtn_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void Form13_Load(object sender, EventArgs e)
        {
            timer1.Start();
            tymlbl.Text = DateTime.Now.ToLongTimeString();
            datelbl.Text = DateTime.Now.ToLongDateString();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Start();
            tymlbl.Text = DateTime.Now.ToLongTimeString();
        }

        private void hmbtn_Click(object sender, EventArgs e)
        {
            DialogResult dialogresult = MessageBox.Show("Are Your goingto logout", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Error);
            if (dialogresult == DialogResult.Yes)
            {
                userlogin f12 = new userlogin();
                f12.Show();
                this.Hide();
            }

        }
    }
}
