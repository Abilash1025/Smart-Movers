﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Smart_Mover
{
    public partial class Record : Form
    {
        public Record()
        {
            InitializeComponent();
        }
        static string connection = @"Data Source=ABI\SQLEXPRESS;Initial Catalog=SmartMovers;Integrated Security=True";
        SqlConnection con = new SqlConnection(connection);
        private void hmbtn_Click(object sender, EventArgs e)
        {
            DialogResult dialogresult = MessageBox.Show("Are Your Sure?", "Configuration", MessageBoxButtons.YesNo, MessageBoxIcon.Error);
            if (dialogresult == DialogResult.Yes)
            {
                Menu f2 = new Menu();
                f2.Show();
                this.Hide();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void exitbtn_Click(object sender, EventArgs e)
        {
            DialogResult dialogresult = MessageBox.Show("Are Your Going to exit?", "Exit Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Error);
            if (dialogresult == DialogResult.Yes)
            {
                Application.Exit();
            }

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Start();
            tymlbl.Text = DateTime.Now.ToLongTimeString();
        }

        private void Record_Load(object sender, EventArgs e)
        {
            
            timer1.Start();
            tymlbl.Text = DateTime.Now.ToLongTimeString();
            datelbl.Text = DateTime.Now.ToLongDateString();
        }

        private void btncustomer_Click(object sender, EventArgs e)
        {
            con.Open();

            SqlDataAdapter dtadpt = new SqlDataAdapter("select * from Customer", con);
            DataTable dttbl = new DataTable();
            dtadpt.Fill(dttbl);
            dataGridView1.DataSource = dttbl;

            con.Close();
        }

        private void btnproduct_Click(object sender, EventArgs e)
        {
            con.Open();

            SqlDataAdapter dtadpt = new SqlDataAdapter("select * from Product", con);
            DataTable dttbl = new DataTable();
            dtadpt.Fill(dttbl);
            dataGridView1.DataSource = dttbl;

            con.Close();
        }

        private void btnload_Click(object sender, EventArgs e)
        {
            con.Open();

            SqlDataAdapter dtadpt = new SqlDataAdapter("select * from Load", con);
            DataTable dttbl = new DataTable();
            dtadpt.Fill(dttbl);
            dataGridView1.DataSource = dttbl;

            con.Close();
        }

        private void btnjob_Click(object sender, EventArgs e)
        {
            con.Open();

            SqlDataAdapter dtadpt = new SqlDataAdapter("select * from Job", con);
            DataTable dttbl = new DataTable();
            dtadpt.Fill(dttbl);
            dataGridView1.DataSource = dttbl;

            con.Close();
        }

        private void btndepot_Click(object sender, EventArgs e)
        {
            con.Open();

            SqlDataAdapter dtadpt = new SqlDataAdapter("select * from Depot", con);
            DataTable dttbl = new DataTable();
            dtadpt.Fill(dttbl);
            dataGridView1.DataSource = dttbl;

            con.Close();
        }

        private void btntransport_Click(object sender, EventArgs e)
        {
            con.Open();

            SqlDataAdapter dtadpt = new SqlDataAdapter("select * from Transport", con);
            DataTable dttbl = new DataTable();
            dtadpt.Fill(dttbl);
            dataGridView1.DataSource = dttbl;

            con.Close();
        }

        private void btnpayment_Click(object sender, EventArgs e)
        {
            con.Open();

            SqlDataAdapter dtadpt = new SqlDataAdapter("select * from Payment", con);
            DataTable dttbl = new DataTable();
            dtadpt.Fill(dttbl);
            dataGridView1.DataSource = dttbl;

            con.Close();
        }
    }
}
