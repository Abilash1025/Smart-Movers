﻿namespace Smart_Mover
{
    partial class Customer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Customer));
            this.panel2 = new System.Windows.Forms.Panel();
            this.button3 = new System.Windows.Forms.Button();
            this.exitbtn = new System.Windows.Forms.Button();
            this.Nxtbtn = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.hmbtn = new System.Windows.Forms.Button();
            this.cstmrlbl = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.frstnmelbl = new System.Windows.Forms.Label();
            this.msglbl = new System.Windows.Forms.Label();
            this.moblelbl = new System.Windows.Forms.Label();
            this.addrsslbl = new System.Windows.Forms.Label();
            this.niclbl = new System.Windows.Forms.Label();
            this.lstnmelbl = new System.Windows.Forms.Label();
            this.lblcstmr = new System.Windows.Forms.Label();
            this.maillbl = new System.Windows.Forms.Label();
            this.scndnolbl = new System.Windows.Forms.Label();
            this.customertxbx = new System.Windows.Forms.TextBox();
            this.Mobilenotxbx = new System.Windows.Forms.TextBox();
            this.addresstxbx = new System.Windows.Forms.TextBox();
            this.NICtxbx = new System.Windows.Forms.TextBox();
            this.lstnametxtbx = new System.Windows.Forms.TextBox();
            this.firstnametxtbx = new System.Windows.Forms.TextBox();
            this.mailtxtbx = new System.Windows.Forms.TextBox();
            this.secondnotxtbx = new System.Windows.Forms.TextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.Clearbtn = new System.Windows.Forms.Button();
            this.btnupdate = new System.Windows.Forms.Button();
            this.btnsearch = new System.Windows.Forms.Button();
            this.btndelete = new System.Windows.Forms.Button();
            this.Savebtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.cat1 = new System.Windows.Forms.RadioButton();
            this.cat2 = new System.Windows.Forms.RadioButton();
            this.cat3 = new System.Windows.Forms.RadioButton();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.tymlbl = new System.Windows.Forms.Label();
            this.datelbl = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.msgingcombobx = new System.Windows.Forms.ComboBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.btnrefresh = new System.Windows.Forms.Button();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.panel2.Controls.Add(this.button3);
            this.panel2.Controls.Add(this.exitbtn);
            this.panel2.Location = new System.Drawing.Point(1157, -4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(127, 769);
            this.panel2.TabIndex = 34;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.button3.Font = new System.Drawing.Font("Cooper Black", 10.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(3, 16);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(62, 52);
            this.button3.TabIndex = 19;
            this.button3.Text = "__";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // exitbtn
            // 
            this.exitbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.exitbtn.Font = new System.Drawing.Font("Trebuchet MS", 18F, System.Drawing.FontStyle.Bold);
            this.exitbtn.ForeColor = System.Drawing.Color.White;
            this.exitbtn.Location = new System.Drawing.Point(62, 16);
            this.exitbtn.Name = "exitbtn";
            this.exitbtn.Size = new System.Drawing.Size(62, 52);
            this.exitbtn.TabIndex = 20;
            this.exitbtn.Text = "x";
            this.exitbtn.UseVisualStyleBackColor = false;
            this.exitbtn.Click += new System.EventHandler(this.exitbtn_Click);
            // 
            // Nxtbtn
            // 
            this.Nxtbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.Nxtbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Nxtbtn.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Nxtbtn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Nxtbtn.Location = new System.Drawing.Point(19, 8);
            this.Nxtbtn.Name = "Nxtbtn";
            this.Nxtbtn.Size = new System.Drawing.Size(90, 40);
            this.Nxtbtn.TabIndex = 17;
            this.Nxtbtn.Text = "Next";
            this.Nxtbtn.UseVisualStyleBackColor = false;
            this.Nxtbtn.Click += new System.EventHandler(this.Nxtbtn_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(45)))), ((int)(((byte)(40)))));
            this.panel1.Controls.Add(this.hmbtn);
            this.panel1.Location = new System.Drawing.Point(0, -4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1283, 70);
            this.panel1.TabIndex = 32;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // hmbtn
            // 
            this.hmbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(45)))), ((int)(((byte)(40)))));
            this.hmbtn.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hmbtn.ForeColor = System.Drawing.Color.White;
            this.hmbtn.Location = new System.Drawing.Point(3, 10);
            this.hmbtn.Name = "hmbtn";
            this.hmbtn.Size = new System.Drawing.Size(74, 52);
            this.hmbtn.TabIndex = 18;
            this.hmbtn.Text = "Home";
            this.hmbtn.UseVisualStyleBackColor = false;
            this.hmbtn.Click += new System.EventHandler(this.hmbtn_Click);
            // 
            // cstmrlbl
            // 
            this.cstmrlbl.AutoSize = true;
            this.cstmrlbl.BackColor = System.Drawing.Color.Transparent;
            this.cstmrlbl.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cstmrlbl.Font = new System.Drawing.Font("Times New Roman", 36F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cstmrlbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(20)))), ((int)(((byte)(30)))));
            this.cstmrlbl.Location = new System.Drawing.Point(503, 69);
            this.cstmrlbl.Name = "cstmrlbl";
            this.cstmrlbl.Size = new System.Drawing.Size(270, 67);
            this.cstmrlbl.TabIndex = 4;
            this.cstmrlbl.Text = "Customer";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(30)))), ((int)(((byte)(40)))));
            this.panel3.Location = new System.Drawing.Point(-1, 134);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1158, 10);
            this.panel3.TabIndex = 7;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // frstnmelbl
            // 
            this.frstnmelbl.AutoSize = true;
            this.frstnmelbl.Font = new System.Drawing.Font("Trebuchet MS", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.frstnmelbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.frstnmelbl.Location = new System.Drawing.Point(12, 254);
            this.frstnmelbl.Name = "frstnmelbl";
            this.frstnmelbl.Size = new System.Drawing.Size(135, 29);
            this.frstnmelbl.TabIndex = 0;
            this.frstnmelbl.Text = "First Name";
            // 
            // msglbl
            // 
            this.msglbl.AutoSize = true;
            this.msglbl.Font = new System.Drawing.Font("Trebuchet MS", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.msglbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.msglbl.Location = new System.Drawing.Point(12, 715);
            this.msglbl.Name = "msglbl";
            this.msglbl.Size = new System.Drawing.Size(123, 29);
            this.msglbl.TabIndex = 8;
            this.msglbl.Text = "Messaging";
            // 
            // moblelbl
            // 
            this.moblelbl.AutoSize = true;
            this.moblelbl.Font = new System.Drawing.Font("Trebuchet MS", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.moblelbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.moblelbl.Location = new System.Drawing.Point(12, 525);
            this.moblelbl.Name = "moblelbl";
            this.moblelbl.Size = new System.Drawing.Size(124, 29);
            this.moblelbl.TabIndex = 10;
            this.moblelbl.Text = "Mobile No";
            // 
            // addrsslbl
            // 
            this.addrsslbl.AutoSize = true;
            this.addrsslbl.Font = new System.Drawing.Font("Trebuchet MS", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addrsslbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.addrsslbl.Location = new System.Drawing.Point(12, 449);
            this.addrsslbl.Name = "addrsslbl";
            this.addrsslbl.Size = new System.Drawing.Size(100, 29);
            this.addrsslbl.TabIndex = 11;
            this.addrsslbl.Text = "Address";
            // 
            // niclbl
            // 
            this.niclbl.AutoSize = true;
            this.niclbl.Font = new System.Drawing.Font("Trebuchet MS", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.niclbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.niclbl.Location = new System.Drawing.Point(12, 370);
            this.niclbl.Name = "niclbl";
            this.niclbl.Size = new System.Drawing.Size(88, 29);
            this.niclbl.TabIndex = 12;
            this.niclbl.Text = "NIC No";
            // 
            // lstnmelbl
            // 
            this.lstnmelbl.AutoSize = true;
            this.lstnmelbl.Font = new System.Drawing.Font("Trebuchet MS", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstnmelbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.lstnmelbl.Location = new System.Drawing.Point(12, 312);
            this.lstnmelbl.Name = "lstnmelbl";
            this.lstnmelbl.Size = new System.Drawing.Size(130, 29);
            this.lstnmelbl.TabIndex = 13;
            this.lstnmelbl.Text = "Last Name";
            // 
            // lblcstmr
            // 
            this.lblcstmr.AutoSize = true;
            this.lblcstmr.Font = new System.Drawing.Font("Trebuchet MS", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcstmr.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.lblcstmr.Location = new System.Drawing.Point(12, 157);
            this.lblcstmr.Name = "lblcstmr";
            this.lblcstmr.Size = new System.Drawing.Size(150, 29);
            this.lblcstmr.TabIndex = 14;
            this.lblcstmr.Text = "Customer ID";
            // 
            // maillbl
            // 
            this.maillbl.AutoSize = true;
            this.maillbl.Font = new System.Drawing.Font("Trebuchet MS", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maillbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.maillbl.Location = new System.Drawing.Point(12, 653);
            this.maillbl.Name = "maillbl";
            this.maillbl.Size = new System.Drawing.Size(75, 29);
            this.maillbl.TabIndex = 15;
            this.maillbl.Text = "Email";
            // 
            // scndnolbl
            // 
            this.scndnolbl.AutoSize = true;
            this.scndnolbl.Font = new System.Drawing.Font("Trebuchet MS", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.scndnolbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.scndnolbl.Location = new System.Drawing.Point(12, 589);
            this.scndnolbl.Name = "scndnolbl";
            this.scndnolbl.Size = new System.Drawing.Size(130, 29);
            this.scndnolbl.TabIndex = 16;
            this.scndnolbl.Text = "Second No";
            // 
            // customertxbx
            // 
            this.customertxbx.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.customertxbx.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.customertxbx.Location = new System.Drawing.Point(220, 156);
            this.customertxbx.Multiline = true;
            this.customertxbx.Name = "customertxbx";
            this.customertxbx.Size = new System.Drawing.Size(220, 36);
            this.customertxbx.TabIndex = 0;
            // 
            // Mobilenotxbx
            // 
            this.Mobilenotxbx.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Mobilenotxbx.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.Mobilenotxbx.Location = new System.Drawing.Point(220, 524);
            this.Mobilenotxbx.Multiline = true;
            this.Mobilenotxbx.Name = "Mobilenotxbx";
            this.Mobilenotxbx.Size = new System.Drawing.Size(220, 36);
            this.Mobilenotxbx.TabIndex = 6;
            // 
            // addresstxbx
            // 
            this.addresstxbx.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addresstxbx.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.addresstxbx.Location = new System.Drawing.Point(220, 430);
            this.addresstxbx.Multiline = true;
            this.addresstxbx.Name = "addresstxbx";
            this.addresstxbx.Size = new System.Drawing.Size(220, 76);
            this.addresstxbx.TabIndex = 5;
            // 
            // NICtxbx
            // 
            this.NICtxbx.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NICtxbx.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.NICtxbx.Location = new System.Drawing.Point(220, 369);
            this.NICtxbx.Multiline = true;
            this.NICtxbx.Name = "NICtxbx";
            this.NICtxbx.Size = new System.Drawing.Size(220, 36);
            this.NICtxbx.TabIndex = 4;
            // 
            // lstnametxtbx
            // 
            this.lstnametxtbx.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstnametxtbx.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.lstnametxtbx.Location = new System.Drawing.Point(220, 311);
            this.lstnametxtbx.Multiline = true;
            this.lstnametxtbx.Name = "lstnametxtbx";
            this.lstnametxtbx.Size = new System.Drawing.Size(220, 36);
            this.lstnametxtbx.TabIndex = 3;
            // 
            // firstnametxtbx
            // 
            this.firstnametxtbx.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.firstnametxtbx.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.firstnametxtbx.Location = new System.Drawing.Point(220, 253);
            this.firstnametxtbx.Multiline = true;
            this.firstnametxtbx.Name = "firstnametxtbx";
            this.firstnametxtbx.Size = new System.Drawing.Size(220, 36);
            this.firstnametxtbx.TabIndex = 2;
            // 
            // mailtxtbx
            // 
            this.mailtxtbx.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mailtxtbx.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.mailtxtbx.Location = new System.Drawing.Point(220, 652);
            this.mailtxtbx.Multiline = true;
            this.mailtxtbx.Name = "mailtxtbx";
            this.mailtxtbx.Size = new System.Drawing.Size(220, 36);
            this.mailtxtbx.TabIndex = 8;
            this.mailtxtbx.Click += new System.EventHandler(this.mailtxtbx_Click);
            // 
            // secondnotxtbx
            // 
            this.secondnotxtbx.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.secondnotxtbx.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.secondnotxtbx.Location = new System.Drawing.Point(220, 588);
            this.secondnotxtbx.Multiline = true;
            this.secondnotxtbx.Name = "secondnotxtbx";
            this.secondnotxtbx.Size = new System.Drawing.Size(220, 36);
            this.secondnotxtbx.TabIndex = 7;
            this.secondnotxtbx.Click += new System.EventHandler(this.secondnotxtbx_Click);
            this.secondnotxtbx.TextChanged += new System.EventHandler(this.secondnotxtbx_TextChanged);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(30)))), ((int)(((byte)(40)))));
            this.panel4.Controls.Add(this.Clearbtn);
            this.panel4.Controls.Add(this.btnupdate);
            this.panel4.Controls.Add(this.btnsearch);
            this.panel4.Controls.Add(this.btndelete);
            this.panel4.Controls.Add(this.Savebtn);
            this.panel4.Location = new System.Drawing.Point(498, 144);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(154, 621);
            this.panel4.TabIndex = 30;
            this.panel4.Paint += new System.Windows.Forms.PaintEventHandler(this.panel4_Paint);
            // 
            // Clearbtn
            // 
            this.Clearbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(30)))), ((int)(((byte)(40)))));
            this.Clearbtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.Clearbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Clearbtn.Font = new System.Drawing.Font("Trebuchet MS", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Clearbtn.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.Clearbtn.Image = ((System.Drawing.Image)(resources.GetObject("Clearbtn.Image")));
            this.Clearbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Clearbtn.Location = new System.Drawing.Point(0, 562);
            this.Clearbtn.Name = "Clearbtn";
            this.Clearbtn.Size = new System.Drawing.Size(154, 52);
            this.Clearbtn.TabIndex = 14;
            this.Clearbtn.Text = "Clear";
            this.Clearbtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Clearbtn.UseVisualStyleBackColor = false;
            this.Clearbtn.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnupdate
            // 
            this.btnupdate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(30)))), ((int)(((byte)(40)))));
            this.btnupdate.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnupdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnupdate.Font = new System.Drawing.Font("Trebuchet MS", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnupdate.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnupdate.Image = ((System.Drawing.Image)(resources.GetObject("btnupdate.Image")));
            this.btnupdate.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnupdate.Location = new System.Drawing.Point(0, 65);
            this.btnupdate.Name = "btnupdate";
            this.btnupdate.Size = new System.Drawing.Size(154, 52);
            this.btnupdate.TabIndex = 11;
            this.btnupdate.Text = "Update";
            this.btnupdate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnupdate.UseVisualStyleBackColor = false;
            this.btnupdate.Click += new System.EventHandler(this.btnupdate_Click);
            // 
            // btnsearch
            // 
            this.btnsearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(30)))), ((int)(((byte)(40)))));
            this.btnsearch.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnsearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnsearch.Font = new System.Drawing.Font("Trebuchet MS", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsearch.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnsearch.Image = ((System.Drawing.Image)(resources.GetObject("btnsearch.Image")));
            this.btnsearch.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnsearch.Location = new System.Drawing.Point(0, 135);
            this.btnsearch.Name = "btnsearch";
            this.btnsearch.Size = new System.Drawing.Size(154, 52);
            this.btnsearch.TabIndex = 12;
            this.btnsearch.Text = "Search";
            this.btnsearch.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnsearch.UseVisualStyleBackColor = false;
            this.btnsearch.Click += new System.EventHandler(this.btnsearch_Click);
            // 
            // btndelete
            // 
            this.btndelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(30)))), ((int)(((byte)(40)))));
            this.btndelete.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btndelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btndelete.Font = new System.Drawing.Font("Trebuchet MS", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndelete.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btndelete.Image = ((System.Drawing.Image)(resources.GetObject("btndelete.Image")));
            this.btndelete.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btndelete.Location = new System.Drawing.Point(0, 205);
            this.btndelete.Name = "btndelete";
            this.btndelete.Size = new System.Drawing.Size(154, 52);
            this.btndelete.TabIndex = 13;
            this.btndelete.Text = "Delete";
            this.btndelete.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btndelete.UseVisualStyleBackColor = false;
            this.btndelete.Click += new System.EventHandler(this.btndelete_Click);
            // 
            // Savebtn
            // 
            this.Savebtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(30)))), ((int)(((byte)(40)))));
            this.Savebtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.Savebtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Savebtn.Font = new System.Drawing.Font("Trebuchet MS", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Savebtn.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.Savebtn.Image = ((System.Drawing.Image)(resources.GetObject("Savebtn.Image")));
            this.Savebtn.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Savebtn.Location = new System.Drawing.Point(0, 2);
            this.Savebtn.Name = "Savebtn";
            this.Savebtn.Size = new System.Drawing.Size(154, 52);
            this.Savebtn.TabIndex = 10;
            this.Savebtn.Text = "Save";
            this.Savebtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Savebtn.UseVisualStyleBackColor = false;
            this.Savebtn.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Trebuchet MS", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.label1.Location = new System.Drawing.Point(12, 202);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(114, 29);
            this.label1.TabIndex = 29;
            this.label1.Text = "Category";
            // 
            // cat1
            // 
            this.cat1.AutoSize = true;
            this.cat1.Font = new System.Drawing.Font("Trebuchet MS", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cat1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.cat1.Location = new System.Drawing.Point(220, 209);
            this.cat1.Name = "cat1";
            this.cat1.Size = new System.Drawing.Size(45, 22);
            this.cat1.TabIndex = 1;
            this.cat1.TabStop = true;
            this.cat1.Text = "01";
            this.cat1.UseVisualStyleBackColor = true;
            this.cat1.CheckedChanged += new System.EventHandler(this.cat1_CheckedChanged);
            // 
            // cat2
            // 
            this.cat2.AutoSize = true;
            this.cat2.Font = new System.Drawing.Font("Trebuchet MS", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cat2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.cat2.Location = new System.Drawing.Point(281, 209);
            this.cat2.Name = "cat2";
            this.cat2.Size = new System.Drawing.Size(45, 22);
            this.cat2.TabIndex = 2;
            this.cat2.TabStop = true;
            this.cat2.Text = "02";
            this.cat2.UseVisualStyleBackColor = true;
            this.cat2.CheckedChanged += new System.EventHandler(this.cat2_CheckedChanged);
            // 
            // cat3
            // 
            this.cat3.AutoSize = true;
            this.cat3.Font = new System.Drawing.Font("Trebuchet MS", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cat3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.cat3.Location = new System.Drawing.Point(343, 209);
            this.cat3.Name = "cat3";
            this.cat3.Size = new System.Drawing.Size(45, 22);
            this.cat3.TabIndex = 3;
            this.cat3.TabStop = true;
            this.cat3.Text = "03";
            this.cat3.UseVisualStyleBackColor = true;
            this.cat3.CheckedChanged += new System.EventHandler(this.cat3_CheckedChanged);
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(658, 179);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(492, 327);
            this.dataGridView1.TabIndex = 32;
            this.dataGridView1.DoubleClick += new System.EventHandler(this.dataGridView1_DoubleClick);
            // 
            // tymlbl
            // 
            this.tymlbl.AutoSize = true;
            this.tymlbl.Font = new System.Drawing.Font("Trebuchet MS", 13.8F, System.Drawing.FontStyle.Bold);
            this.tymlbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.tymlbl.Location = new System.Drawing.Point(654, 722);
            this.tymlbl.Name = "tymlbl";
            this.tymlbl.Size = new System.Drawing.Size(69, 29);
            this.tymlbl.TabIndex = 33;
            this.tymlbl.Text = "Time";
            // 
            // datelbl
            // 
            this.datelbl.AutoSize = true;
            this.datelbl.Font = new System.Drawing.Font("Trebuchet MS", 13.8F, System.Drawing.FontStyle.Bold);
            this.datelbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.datelbl.Location = new System.Drawing.Point(821, 722);
            this.datelbl.Name = "datelbl";
            this.datelbl.Size = new System.Drawing.Size(65, 29);
            this.datelbl.TabIndex = 34;
            this.datelbl.Text = "Date";
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // msgingcombobx
            // 
            this.msgingcombobx.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold);
            this.msgingcombobx.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.msgingcombobx.FormattingEnabled = true;
            this.msgingcombobx.Items.AddRange(new object[] {
            "Whatsapp",
            "Viber",
            "IMO"});
            this.msgingcombobx.Location = new System.Drawing.Point(220, 710);
            this.msgingcombobx.Name = "msgingcombobx";
            this.msgingcombobx.Size = new System.Drawing.Size(220, 34);
            this.msgingcombobx.TabIndex = 9;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.panel5.Controls.Add(this.Nxtbtn);
            this.panel5.Location = new System.Drawing.Point(1159, 701);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(121, 57);
            this.panel5.TabIndex = 31;
            // 
            // btnrefresh
            // 
            this.btnrefresh.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(65)))), ((int)(((byte)(65)))));
            this.btnrefresh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnrefresh.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnrefresh.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnrefresh.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnrefresh.Location = new System.Drawing.Point(863, 525);
            this.btnrefresh.Name = "btnrefresh";
            this.btnrefresh.Size = new System.Drawing.Size(116, 40);
            this.btnrefresh.TabIndex = 16;
            this.btnrefresh.Text = "Refresh";
            this.btnrefresh.UseVisualStyleBackColor = false;
            this.btnrefresh.Click += new System.EventHandler(this.btnrefresh_Click);
            // 
            // Customer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1282, 760);
            this.ControlBox = false;
            this.Controls.Add(this.btnrefresh);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.msgingcombobx);
            this.Controls.Add(this.datelbl);
            this.Controls.Add(this.tymlbl);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.cat3);
            this.Controls.Add(this.cat2);
            this.Controls.Add(this.cat1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.secondnotxtbx);
            this.Controls.Add(this.mailtxtbx);
            this.Controls.Add(this.firstnametxtbx);
            this.Controls.Add(this.lstnametxtbx);
            this.Controls.Add(this.NICtxbx);
            this.Controls.Add(this.addresstxbx);
            this.Controls.Add(this.Mobilenotxbx);
            this.Controls.Add(this.customertxbx);
            this.Controls.Add(this.scndnolbl);
            this.Controls.Add(this.maillbl);
            this.Controls.Add(this.lblcstmr);
            this.Controls.Add(this.lstnmelbl);
            this.Controls.Add(this.niclbl);
            this.Controls.Add(this.addrsslbl);
            this.Controls.Add(this.moblelbl);
            this.Controls.Add(this.msglbl);
            this.Controls.Add(this.frstnmelbl);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.cstmrlbl);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximumSize = new System.Drawing.Size(1300, 807);
            this.Name = "Customer";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Customer";
            this.Load += new System.EventHandler(this.Form3_Load);
            this.panel2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel5.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button exitbtn;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button hmbtn;
        private System.Windows.Forms.Label cstmrlbl;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label frstnmelbl;
        private System.Windows.Forms.Label msglbl;
        private System.Windows.Forms.Label moblelbl;
        private System.Windows.Forms.Label addrsslbl;
        private System.Windows.Forms.Label niclbl;
        private System.Windows.Forms.Label lstnmelbl;
        private System.Windows.Forms.Label lblcstmr;
        private System.Windows.Forms.Label maillbl;
        private System.Windows.Forms.Label scndnolbl;
        private System.Windows.Forms.TextBox customertxbx;
        private System.Windows.Forms.TextBox Mobilenotxbx;
        private System.Windows.Forms.TextBox addresstxbx;
        private System.Windows.Forms.TextBox NICtxbx;
        private System.Windows.Forms.TextBox lstnametxtbx;
        private System.Windows.Forms.TextBox firstnametxtbx;
        private System.Windows.Forms.TextBox mailtxtbx;
        private System.Windows.Forms.TextBox secondnotxtbx;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton cat1;
        private System.Windows.Forms.RadioButton cat2;
        private System.Windows.Forms.RadioButton cat3;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label tymlbl;
        private System.Windows.Forms.Label datelbl;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.ComboBox msgingcombobx;
        private System.Windows.Forms.Button Savebtn;
        private System.Windows.Forms.Button btnupdate;
        private System.Windows.Forms.Button btnsearch;
        private System.Windows.Forms.Button btndelete;
        private System.Windows.Forms.Button Clearbtn;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button Nxtbtn;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button btnrefresh;


    }
}