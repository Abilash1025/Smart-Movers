﻿namespace Smart_Mover
{
    partial class Transport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Transport));
            this.btnclear = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.Nxtbtn = new System.Windows.Forms.Button();
            this.minimizebtn = new System.Windows.Forms.Button();
            this.exitbtn = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.hmbtn = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.btnupdate = new System.Windows.Forms.Button();
            this.btnsearch = new System.Windows.Forms.Button();
            this.btndelete = new System.Windows.Forms.Button();
            this.Savebtn = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.datelbl = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.tymlbl = new System.Windows.Forms.Label();
            this.trnstlbl = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.transportidtxtbxtxbx = new System.Windows.Forms.TextBox();
            this.trnasportidlbl = new System.Windows.Forms.Label();
            this.drvrtrxtbx = new System.Windows.Forms.TextBox();
            this.drvrlbl = new System.Windows.Forms.Label();
            this.assttnttxtbx = new System.Windows.Forms.TextBox();
            this.aastntlbl = new System.Windows.Forms.Label();
            this.depotcmbbx = new System.Windows.Forms.ComboBox();
            this.depotlbl = new System.Windows.Forms.Label();
            this.lorrycmbbx = new System.Windows.Forms.ComboBox();
            this.lrylbl = new System.Windows.Forms.Label();
            this.btnrefresh = new System.Windows.Forms.Button();
            this.cmbcontainer = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnclear.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnclear
            // 
            this.btnclear.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.btnclear.Controls.Add(this.panel5);
            this.btnclear.Controls.Add(this.minimizebtn);
            this.btnclear.Controls.Add(this.exitbtn);
            this.btnclear.Location = new System.Drawing.Point(1156, -4);
            this.btnclear.Name = "btnclear";
            this.btnclear.Size = new System.Drawing.Size(127, 769);
            this.btnclear.TabIndex = 16;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.panel5.Controls.Add(this.Nxtbtn);
            this.panel5.Location = new System.Drawing.Point(3, 707);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(127, 57);
            this.panel5.TabIndex = 14;
            // 
            // Nxtbtn
            // 
            this.Nxtbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.Nxtbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Nxtbtn.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Nxtbtn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Nxtbtn.Location = new System.Drawing.Point(22, 8);
            this.Nxtbtn.Name = "Nxtbtn";
            this.Nxtbtn.Size = new System.Drawing.Size(90, 40);
            this.Nxtbtn.TabIndex = 15;
            this.Nxtbtn.Text = "Next";
            this.Nxtbtn.UseVisualStyleBackColor = false;
            this.Nxtbtn.Click += new System.EventHandler(this.Nxtbtn_Click);
            // 
            // minimizebtn
            // 
            this.minimizebtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.minimizebtn.Font = new System.Drawing.Font("Cooper Black", 10.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.minimizebtn.ForeColor = System.Drawing.Color.White;
            this.minimizebtn.Location = new System.Drawing.Point(3, 15);
            this.minimizebtn.Name = "minimizebtn";
            this.minimizebtn.Size = new System.Drawing.Size(62, 52);
            this.minimizebtn.TabIndex = 17;
            this.minimizebtn.Text = "__";
            this.minimizebtn.UseVisualStyleBackColor = false;
            this.minimizebtn.Click += new System.EventHandler(this.minimizebtn_Click);
            // 
            // exitbtn
            // 
            this.exitbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.exitbtn.Font = new System.Drawing.Font("Trebuchet MS", 18F, System.Drawing.FontStyle.Bold);
            this.exitbtn.ForeColor = System.Drawing.Color.White;
            this.exitbtn.Location = new System.Drawing.Point(63, 15);
            this.exitbtn.Name = "exitbtn";
            this.exitbtn.Size = new System.Drawing.Size(62, 52);
            this.exitbtn.TabIndex = 18;
            this.exitbtn.Text = "x";
            this.exitbtn.UseVisualStyleBackColor = false;
            this.exitbtn.Click += new System.EventHandler(this.exitbtn_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(45)))), ((int)(((byte)(40)))));
            this.panel1.Controls.Add(this.hmbtn);
            this.panel1.Location = new System.Drawing.Point(0, -4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1283, 70);
            this.panel1.TabIndex = 15;
            // 
            // hmbtn
            // 
            this.hmbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(45)))), ((int)(((byte)(40)))));
            this.hmbtn.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hmbtn.ForeColor = System.Drawing.Color.White;
            this.hmbtn.Location = new System.Drawing.Point(3, 10);
            this.hmbtn.Name = "hmbtn";
            this.hmbtn.Size = new System.Drawing.Size(74, 52);
            this.hmbtn.TabIndex = 16;
            this.hmbtn.Text = "Home";
            this.hmbtn.UseVisualStyleBackColor = false;
            this.hmbtn.Click += new System.EventHandler(this.hmbtn_Click);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(30)))), ((int)(((byte)(40)))));
            this.panel4.Controls.Add(this.button2);
            this.panel4.Controls.Add(this.btnupdate);
            this.panel4.Controls.Add(this.btnsearch);
            this.panel4.Controls.Add(this.btndelete);
            this.panel4.Controls.Add(this.Savebtn);
            this.panel4.Location = new System.Drawing.Point(498, 154);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(154, 611);
            this.panel4.TabIndex = 8;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(30)))), ((int)(((byte)(40)))));
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Trebuchet MS", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.button2.Image = ((System.Drawing.Image)(resources.GetObject("button2.Image")));
            this.button2.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button2.Location = new System.Drawing.Point(0, 554);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(154, 52);
            this.button2.TabIndex = 12;
            this.button2.Text = "Clear";
            this.button2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnupdate
            // 
            this.btnupdate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(30)))), ((int)(((byte)(40)))));
            this.btnupdate.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnupdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnupdate.Font = new System.Drawing.Font("Trebuchet MS", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnupdate.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnupdate.Image = ((System.Drawing.Image)(resources.GetObject("btnupdate.Image")));
            this.btnupdate.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnupdate.Location = new System.Drawing.Point(0, 62);
            this.btnupdate.Name = "btnupdate";
            this.btnupdate.Size = new System.Drawing.Size(154, 52);
            this.btnupdate.TabIndex = 9;
            this.btnupdate.Text = "Update";
            this.btnupdate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnupdate.UseVisualStyleBackColor = false;
            this.btnupdate.Click += new System.EventHandler(this.btnupdate_Click);
            // 
            // btnsearch
            // 
            this.btnsearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(30)))), ((int)(((byte)(40)))));
            this.btnsearch.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnsearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnsearch.Font = new System.Drawing.Font("Trebuchet MS", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsearch.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnsearch.Image = ((System.Drawing.Image)(resources.GetObject("btnsearch.Image")));
            this.btnsearch.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnsearch.Location = new System.Drawing.Point(0, 132);
            this.btnsearch.Name = "btnsearch";
            this.btnsearch.Size = new System.Drawing.Size(154, 52);
            this.btnsearch.TabIndex = 10;
            this.btnsearch.Text = "Search";
            this.btnsearch.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnsearch.UseVisualStyleBackColor = false;
            this.btnsearch.Click += new System.EventHandler(this.btnsearch_Click);
            // 
            // btndelete
            // 
            this.btndelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(30)))), ((int)(((byte)(40)))));
            this.btndelete.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btndelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btndelete.Font = new System.Drawing.Font("Trebuchet MS", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndelete.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btndelete.Image = ((System.Drawing.Image)(resources.GetObject("btndelete.Image")));
            this.btndelete.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btndelete.Location = new System.Drawing.Point(0, 202);
            this.btndelete.Name = "btndelete";
            this.btndelete.Size = new System.Drawing.Size(154, 52);
            this.btndelete.TabIndex = 11;
            this.btndelete.Text = "Delete";
            this.btndelete.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btndelete.UseVisualStyleBackColor = false;
            this.btndelete.Click += new System.EventHandler(this.btndelete_Click);
            // 
            // Savebtn
            // 
            this.Savebtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(30)))), ((int)(((byte)(40)))));
            this.Savebtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.Savebtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Savebtn.Font = new System.Drawing.Font("Trebuchet MS", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Savebtn.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.Savebtn.Image = ((System.Drawing.Image)(resources.GetObject("Savebtn.Image")));
            this.Savebtn.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Savebtn.Location = new System.Drawing.Point(0, -1);
            this.Savebtn.Name = "Savebtn";
            this.Savebtn.Size = new System.Drawing.Size(154, 52);
            this.Savebtn.TabIndex = 8;
            this.Savebtn.Text = "Save";
            this.Savebtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Savebtn.UseVisualStyleBackColor = false;
            this.Savebtn.Click += new System.EventHandler(this.Savebtn_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(30)))), ((int)(((byte)(40)))));
            this.panel3.Location = new System.Drawing.Point(-1, 144);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1185, 10);
            this.panel3.TabIndex = 35;
            // 
            // datelbl
            // 
            this.datelbl.AutoSize = true;
            this.datelbl.Font = new System.Drawing.Font("Trebuchet MS", 13.8F, System.Drawing.FontStyle.Bold);
            this.datelbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.datelbl.Location = new System.Drawing.Point(819, 722);
            this.datelbl.Name = "datelbl";
            this.datelbl.Size = new System.Drawing.Size(65, 29);
            this.datelbl.TabIndex = 116;
            this.datelbl.Text = "Date";
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(657, 176);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(492, 327);
            this.dataGridView1.TabIndex = 115;
            this.dataGridView1.DoubleClick += new System.EventHandler(this.dataGridView1_DoubleClick);
            // 
            // tymlbl
            // 
            this.tymlbl.AutoSize = true;
            this.tymlbl.Font = new System.Drawing.Font("Trebuchet MS", 13.8F, System.Drawing.FontStyle.Bold);
            this.tymlbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.tymlbl.Location = new System.Drawing.Point(654, 722);
            this.tymlbl.Name = "tymlbl";
            this.tymlbl.Size = new System.Drawing.Size(69, 29);
            this.tymlbl.TabIndex = 117;
            this.tymlbl.Text = "Time";
            // 
            // trnstlbl
            // 
            this.trnstlbl.AutoSize = true;
            this.trnstlbl.BackColor = System.Drawing.Color.Transparent;
            this.trnstlbl.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.trnstlbl.Font = new System.Drawing.Font("Times New Roman", 36F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.trnstlbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(20)))), ((int)(((byte)(30)))));
            this.trnstlbl.Location = new System.Drawing.Point(466, 69);
            this.trnstlbl.Name = "trnstlbl";
            this.trnstlbl.Size = new System.Drawing.Size(273, 67);
            this.trnstlbl.TabIndex = 118;
            this.trnstlbl.Text = "Transport";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // transportidtxtbxtxbx
            // 
            this.transportidtxtbxtxbx.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.transportidtxtbxtxbx.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.transportidtxtbxtxbx.Location = new System.Drawing.Point(235, 187);
            this.transportidtxtbxtxbx.Multiline = true;
            this.transportidtxtbxtxbx.Name = "transportidtxtbxtxbx";
            this.transportidtxtbxtxbx.Size = new System.Drawing.Size(220, 36);
            this.transportidtxtbxtxbx.TabIndex = 1;
            // 
            // trnasportidlbl
            // 
            this.trnasportidlbl.AutoSize = true;
            this.trnasportidlbl.Font = new System.Drawing.Font("Trebuchet MS", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.trnasportidlbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.trnasportidlbl.Location = new System.Drawing.Point(12, 188);
            this.trnasportidlbl.Name = "trnasportidlbl";
            this.trnasportidlbl.Size = new System.Drawing.Size(149, 29);
            this.trnasportidlbl.TabIndex = 120;
            this.trnasportidlbl.Text = "Transport ID";
            // 
            // drvrtrxtbx
            // 
            this.drvrtrxtbx.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.drvrtrxtbx.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.drvrtrxtbx.Location = new System.Drawing.Point(235, 250);
            this.drvrtrxtbx.Multiline = true;
            this.drvrtrxtbx.Name = "drvrtrxtbx";
            this.drvrtrxtbx.Size = new System.Drawing.Size(220, 36);
            this.drvrtrxtbx.TabIndex = 2;
            // 
            // drvrlbl
            // 
            this.drvrlbl.AutoSize = true;
            this.drvrlbl.Font = new System.Drawing.Font("Trebuchet MS", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.drvrlbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.drvrlbl.Location = new System.Drawing.Point(12, 251);
            this.drvrlbl.Name = "drvrlbl";
            this.drvrlbl.Size = new System.Drawing.Size(82, 29);
            this.drvrlbl.TabIndex = 122;
            this.drvrlbl.Text = "Driver";
            // 
            // assttnttxtbx
            // 
            this.assttnttxtbx.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.assttnttxtbx.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.assttnttxtbx.Location = new System.Drawing.Point(235, 308);
            this.assttnttxtbx.Multiline = true;
            this.assttnttxtbx.Name = "assttnttxtbx";
            this.assttnttxtbx.Size = new System.Drawing.Size(220, 36);
            this.assttnttxtbx.TabIndex = 3;
            // 
            // aastntlbl
            // 
            this.aastntlbl.AutoSize = true;
            this.aastntlbl.Font = new System.Drawing.Font("Trebuchet MS", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.aastntlbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.aastntlbl.Location = new System.Drawing.Point(12, 309);
            this.aastntlbl.Name = "aastntlbl";
            this.aastntlbl.Size = new System.Drawing.Size(112, 29);
            this.aastntlbl.TabIndex = 124;
            this.aastntlbl.Text = "Assistant";
            // 
            // depotcmbbx
            // 
            this.depotcmbbx.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold);
            this.depotcmbbx.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.depotcmbbx.FormattingEnabled = true;
            this.depotcmbbx.Location = new System.Drawing.Point(238, 489);
            this.depotcmbbx.Name = "depotcmbbx";
            this.depotcmbbx.Size = new System.Drawing.Size(220, 34);
            this.depotcmbbx.TabIndex = 7;
            // 
            // depotlbl
            // 
            this.depotlbl.AutoSize = true;
            this.depotlbl.Font = new System.Drawing.Font("Trebuchet MS", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.depotlbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.depotlbl.Location = new System.Drawing.Point(15, 490);
            this.depotlbl.Name = "depotlbl";
            this.depotlbl.Size = new System.Drawing.Size(109, 29);
            this.depotlbl.TabIndex = 126;
            this.depotlbl.Text = "Depot ID";
            // 
            // lorrycmbbx
            // 
            this.lorrycmbbx.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold);
            this.lorrycmbbx.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.lorrycmbbx.FormattingEnabled = true;
            this.lorrycmbbx.Items.AddRange(new object[] {
            "Container Lorry",
            "Light-duty",
            "Cargo Lorry ",
            "Dump Truck",
            "Tow truck",
            "Box Lorry"});
            this.lorrycmbbx.Location = new System.Drawing.Point(235, 368);
            this.lorrycmbbx.Name = "lorrycmbbx";
            this.lorrycmbbx.Size = new System.Drawing.Size(220, 34);
            this.lorrycmbbx.TabIndex = 4;
            // 
            // lrylbl
            // 
            this.lrylbl.AutoSize = true;
            this.lrylbl.Font = new System.Drawing.Font("Trebuchet MS", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lrylbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.lrylbl.Location = new System.Drawing.Point(12, 370);
            this.lrylbl.Name = "lrylbl";
            this.lrylbl.Size = new System.Drawing.Size(73, 29);
            this.lrylbl.TabIndex = 132;
            this.lrylbl.Text = "Lorry";
            // 
            // btnrefresh
            // 
            this.btnrefresh.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(65)))), ((int)(((byte)(65)))));
            this.btnrefresh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnrefresh.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnrefresh.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnrefresh.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnrefresh.Location = new System.Drawing.Point(849, 527);
            this.btnrefresh.Name = "btnrefresh";
            this.btnrefresh.Size = new System.Drawing.Size(116, 40);
            this.btnrefresh.TabIndex = 14;
            this.btnrefresh.Text = "Refresh";
            this.btnrefresh.UseVisualStyleBackColor = false;
            this.btnrefresh.Click += new System.EventHandler(this.btnrefresh_Click);
            // 
            // cmbcontainer
            // 
            this.cmbcontainer.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold);
            this.cmbcontainer.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.cmbcontainer.FormattingEnabled = true;
            this.cmbcontainer.Items.AddRange(new object[] {
            "1 Container ",
            "2 Containers ",
            "3 Containers ",
            "4 Containers ",
            "5 Containers "});
            this.cmbcontainer.Location = new System.Drawing.Point(235, 422);
            this.cmbcontainer.Name = "cmbcontainer";
            this.cmbcontainer.Size = new System.Drawing.Size(220, 34);
            this.cmbcontainer.TabIndex = 133;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Trebuchet MS", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.label1.Location = new System.Drawing.Point(12, 427);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(124, 29);
            this.label1.TabIndex = 134;
            this.label1.Text = "Container";
            // 
            // Transport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1282, 760);
            this.Controls.Add(this.cmbcontainer);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnrefresh);
            this.Controls.Add(this.lorrycmbbx);
            this.Controls.Add(this.lrylbl);
            this.Controls.Add(this.depotcmbbx);
            this.Controls.Add(this.depotlbl);
            this.Controls.Add(this.assttnttxtbx);
            this.Controls.Add(this.aastntlbl);
            this.Controls.Add(this.drvrtrxtbx);
            this.Controls.Add(this.drvrlbl);
            this.Controls.Add(this.transportidtxtbxtxbx);
            this.Controls.Add(this.trnasportidlbl);
            this.Controls.Add(this.trnstlbl);
            this.Controls.Add(this.tymlbl);
            this.Controls.Add(this.datelbl);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.btnclear);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Transport";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form11";
            this.Load += new System.EventHandler(this.Form8_Load);
            this.btnclear.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel btnclear;
        private System.Windows.Forms.Button Nxtbtn;
        private System.Windows.Forms.Button minimizebtn;
        private System.Windows.Forms.Button exitbtn;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button hmbtn;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btnupdate;
        private System.Windows.Forms.Button btnsearch;
        private System.Windows.Forms.Button btndelete;
        private System.Windows.Forms.Button Savebtn;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label datelbl;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label tymlbl;
        private System.Windows.Forms.Label trnstlbl;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.TextBox transportidtxtbxtxbx;
        private System.Windows.Forms.Label trnasportidlbl;
        private System.Windows.Forms.TextBox drvrtrxtbx;
        private System.Windows.Forms.Label drvrlbl;
        private System.Windows.Forms.TextBox assttnttxtbx;
        private System.Windows.Forms.Label aastntlbl;
        private System.Windows.Forms.ComboBox depotcmbbx;
        private System.Windows.Forms.Label depotlbl;
        private System.Windows.Forms.ComboBox lorrycmbbx;
        private System.Windows.Forms.Label lrylbl;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button btnrefresh;
        private System.Windows.Forms.ComboBox cmbcontainer;
        private System.Windows.Forms.Label label1;
    }
}