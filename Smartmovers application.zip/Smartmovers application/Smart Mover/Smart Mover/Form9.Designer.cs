﻿namespace Smart_Mover
{
    partial class Payment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Payment));
            this.panel2 = new System.Windows.Forms.Panel();
            this.minimzebtn = new System.Windows.Forms.Button();
            this.exitbtn = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.hmbtn = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.Clearbtn = new System.Windows.Forms.Button();
            this.btnupdate = new System.Windows.Forms.Button();
            this.btnsearch = new System.Windows.Forms.Button();
            this.btndelete = new System.Windows.Forms.Button();
            this.Savebtn = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.trnstlbl = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.datelbl = new System.Windows.Forms.Label();
            this.tymlbl = new System.Windows.Forms.Label();
            this.paymentidtxtbxtxbx = new System.Windows.Forms.TextBox();
            this.paymentllbl = new System.Windows.Forms.Label();
            this.lblcstmr = new System.Windows.Forms.Label();
            this.Jobcombobx = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.prdctidlbl = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.paymentcombobox = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.datetime = new System.Windows.Forms.DateTimePicker();
            this.amntlbl = new System.Windows.Forms.Label();
            this.Amnttextbox = new System.Windows.Forms.TextBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.panel5 = new System.Windows.Forms.Panel();
            this.button3 = new System.Windows.Forms.Button();
            this.btnrefresh = new System.Windows.Forms.Button();
            this.Custmrcombobx = new System.Windows.Forms.ComboBox();
            this.prdctcombobx = new System.Windows.Forms.ComboBox();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.panel2.Controls.Add(this.minimzebtn);
            this.panel2.Controls.Add(this.exitbtn);
            this.panel2.Location = new System.Drawing.Point(1156, -1);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(127, 769);
            this.panel2.TabIndex = 16;
            // 
            // minimzebtn
            // 
            this.minimzebtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.minimzebtn.Font = new System.Drawing.Font("Cooper Black", 10.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.minimzebtn.ForeColor = System.Drawing.Color.White;
            this.minimzebtn.Location = new System.Drawing.Point(5, 16);
            this.minimzebtn.Name = "minimzebtn";
            this.minimzebtn.Size = new System.Drawing.Size(62, 52);
            this.minimzebtn.TabIndex = 17;
            this.minimzebtn.Text = "__";
            this.minimzebtn.UseVisualStyleBackColor = false;
            this.minimzebtn.Click += new System.EventHandler(this.minimzebtn_Click);
            // 
            // exitbtn
            // 
            this.exitbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.exitbtn.Font = new System.Drawing.Font("Trebuchet MS", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitbtn.ForeColor = System.Drawing.Color.White;
            this.exitbtn.Location = new System.Drawing.Point(64, 16);
            this.exitbtn.Name = "exitbtn";
            this.exitbtn.Size = new System.Drawing.Size(62, 52);
            this.exitbtn.TabIndex = 18;
            this.exitbtn.Text = "x";
            this.exitbtn.UseVisualStyleBackColor = false;
            this.exitbtn.Click += new System.EventHandler(this.exitbtn_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(45)))), ((int)(((byte)(40)))));
            this.panel1.Controls.Add(this.hmbtn);
            this.panel1.Location = new System.Drawing.Point(0, -1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1283, 70);
            this.panel1.TabIndex = 15;
            // 
            // hmbtn
            // 
            this.hmbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(45)))), ((int)(((byte)(40)))));
            this.hmbtn.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hmbtn.ForeColor = System.Drawing.Color.White;
            this.hmbtn.Location = new System.Drawing.Point(3, 11);
            this.hmbtn.Name = "hmbtn";
            this.hmbtn.Size = new System.Drawing.Size(74, 52);
            this.hmbtn.TabIndex = 16;
            this.hmbtn.Text = "Home";
            this.hmbtn.UseVisualStyleBackColor = false;
            this.hmbtn.Click += new System.EventHandler(this.hmbtn_Click);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(30)))), ((int)(((byte)(40)))));
            this.panel4.Controls.Add(this.Clearbtn);
            this.panel4.Controls.Add(this.btnupdate);
            this.panel4.Controls.Add(this.btnsearch);
            this.panel4.Controls.Add(this.btndelete);
            this.panel4.Controls.Add(this.Savebtn);
            this.panel4.Location = new System.Drawing.Point(498, 157);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(154, 611);
            this.panel4.TabIndex = 8;
            // 
            // Clearbtn
            // 
            this.Clearbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(30)))), ((int)(((byte)(40)))));
            this.Clearbtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.Clearbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Clearbtn.Font = new System.Drawing.Font("Trebuchet MS", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Clearbtn.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.Clearbtn.Image = ((System.Drawing.Image)(resources.GetObject("Clearbtn.Image")));
            this.Clearbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Clearbtn.Location = new System.Drawing.Point(-1, 549);
            this.Clearbtn.Name = "Clearbtn";
            this.Clearbtn.Size = new System.Drawing.Size(154, 52);
            this.Clearbtn.TabIndex = 12;
            this.Clearbtn.Text = "Clear";
            this.Clearbtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Clearbtn.UseVisualStyleBackColor = false;
            this.Clearbtn.Click += new System.EventHandler(this.Clearbtn_Click);
            // 
            // btnupdate
            // 
            this.btnupdate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(30)))), ((int)(((byte)(40)))));
            this.btnupdate.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnupdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnupdate.Font = new System.Drawing.Font("Trebuchet MS", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnupdate.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnupdate.Image = ((System.Drawing.Image)(resources.GetObject("btnupdate.Image")));
            this.btnupdate.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnupdate.Location = new System.Drawing.Point(0, 62);
            this.btnupdate.Name = "btnupdate";
            this.btnupdate.Size = new System.Drawing.Size(154, 52);
            this.btnupdate.TabIndex = 9;
            this.btnupdate.Text = "Update";
            this.btnupdate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnupdate.UseVisualStyleBackColor = false;
            this.btnupdate.Click += new System.EventHandler(this.btnupdate_Click);
            // 
            // btnsearch
            // 
            this.btnsearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(30)))), ((int)(((byte)(40)))));
            this.btnsearch.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnsearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnsearch.Font = new System.Drawing.Font("Trebuchet MS", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsearch.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnsearch.Image = ((System.Drawing.Image)(resources.GetObject("btnsearch.Image")));
            this.btnsearch.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnsearch.Location = new System.Drawing.Point(0, 132);
            this.btnsearch.Name = "btnsearch";
            this.btnsearch.Size = new System.Drawing.Size(154, 52);
            this.btnsearch.TabIndex = 10;
            this.btnsearch.Text = "Search";
            this.btnsearch.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnsearch.UseVisualStyleBackColor = false;
            this.btnsearch.Click += new System.EventHandler(this.btnsearch_Click);
            // 
            // btndelete
            // 
            this.btndelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(30)))), ((int)(((byte)(40)))));
            this.btndelete.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btndelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btndelete.Font = new System.Drawing.Font("Trebuchet MS", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndelete.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btndelete.Image = ((System.Drawing.Image)(resources.GetObject("btndelete.Image")));
            this.btndelete.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btndelete.Location = new System.Drawing.Point(0, 202);
            this.btndelete.Name = "btndelete";
            this.btndelete.Size = new System.Drawing.Size(154, 52);
            this.btndelete.TabIndex = 11;
            this.btndelete.Text = "Delete";
            this.btndelete.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btndelete.UseVisualStyleBackColor = false;
            this.btndelete.Click += new System.EventHandler(this.btndelete_Click);
            // 
            // Savebtn
            // 
            this.Savebtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(30)))), ((int)(((byte)(40)))));
            this.Savebtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.Savebtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Savebtn.Font = new System.Drawing.Font("Trebuchet MS", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Savebtn.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.Savebtn.Image = ((System.Drawing.Image)(resources.GetObject("Savebtn.Image")));
            this.Savebtn.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Savebtn.Location = new System.Drawing.Point(1, 0);
            this.Savebtn.Name = "Savebtn";
            this.Savebtn.Size = new System.Drawing.Size(154, 52);
            this.Savebtn.TabIndex = 8;
            this.Savebtn.Text = "Save";
            this.Savebtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Savebtn.UseVisualStyleBackColor = false;
            this.Savebtn.Click += new System.EventHandler(this.Savebtn_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(30)))), ((int)(((byte)(40)))));
            this.panel3.Location = new System.Drawing.Point(-1, 147);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1185, 10);
            this.panel3.TabIndex = 35;
            // 
            // trnstlbl
            // 
            this.trnstlbl.AutoSize = true;
            this.trnstlbl.BackColor = System.Drawing.Color.Transparent;
            this.trnstlbl.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.trnstlbl.Font = new System.Drawing.Font("Times New Roman", 36F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.trnstlbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(20)))), ((int)(((byte)(30)))));
            this.trnstlbl.Location = new System.Drawing.Point(457, 72);
            this.trnstlbl.Name = "trnstlbl";
            this.trnstlbl.Size = new System.Drawing.Size(248, 67);
            this.trnstlbl.TabIndex = 76;
            this.trnstlbl.Text = "Payment";
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(658, 183);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(492, 327);
            this.dataGridView1.TabIndex = 79;
            this.dataGridView1.DoubleClick += new System.EventHandler(this.dataGridView1_DoubleClick);
            // 
            // datelbl
            // 
            this.datelbl.AutoSize = true;
            this.datelbl.Font = new System.Drawing.Font("Trebuchet MS", 13.8F, System.Drawing.FontStyle.Bold);
            this.datelbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.datelbl.Location = new System.Drawing.Point(825, 722);
            this.datelbl.Name = "datelbl";
            this.datelbl.Size = new System.Drawing.Size(65, 29);
            this.datelbl.TabIndex = 81;
            this.datelbl.Text = "Date";
            // 
            // tymlbl
            // 
            this.tymlbl.AutoSize = true;
            this.tymlbl.Font = new System.Drawing.Font("Trebuchet MS", 13.8F, System.Drawing.FontStyle.Bold);
            this.tymlbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.tymlbl.Location = new System.Drawing.Point(658, 722);
            this.tymlbl.Name = "tymlbl";
            this.tymlbl.Size = new System.Drawing.Size(69, 29);
            this.tymlbl.TabIndex = 80;
            this.tymlbl.Text = "Time";
            // 
            // paymentidtxtbxtxbx
            // 
            this.paymentidtxtbxtxbx.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.paymentidtxtbxtxbx.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.paymentidtxtbxtxbx.Location = new System.Drawing.Point(236, 195);
            this.paymentidtxtbxtxbx.Multiline = true;
            this.paymentidtxtbxtxbx.Name = "paymentidtxtbxtxbx";
            this.paymentidtxtbxtxbx.Size = new System.Drawing.Size(220, 36);
            this.paymentidtxtbxtxbx.TabIndex = 1;
            // 
            // paymentllbl
            // 
            this.paymentllbl.AutoSize = true;
            this.paymentllbl.Font = new System.Drawing.Font("Trebuchet MS", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.paymentllbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.paymentllbl.Location = new System.Drawing.Point(28, 196);
            this.paymentllbl.Name = "paymentllbl";
            this.paymentllbl.Size = new System.Drawing.Size(140, 29);
            this.paymentllbl.TabIndex = 86;
            this.paymentllbl.Text = "Payment ID";
            // 
            // lblcstmr
            // 
            this.lblcstmr.AutoSize = true;
            this.lblcstmr.Font = new System.Drawing.Font("Trebuchet MS", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcstmr.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.lblcstmr.Location = new System.Drawing.Point(28, 261);
            this.lblcstmr.Name = "lblcstmr";
            this.lblcstmr.Size = new System.Drawing.Size(150, 29);
            this.lblcstmr.TabIndex = 96;
            this.lblcstmr.Text = "Customer ID";
            // 
            // Jobcombobx
            // 
            this.Jobcombobx.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold);
            this.Jobcombobx.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.Jobcombobx.FormattingEnabled = true;
            this.Jobcombobx.Location = new System.Drawing.Point(236, 387);
            this.Jobcombobx.Name = "Jobcombobx";
            this.Jobcombobx.Size = new System.Drawing.Size(220, 34);
            this.Jobcombobx.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Trebuchet MS", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.label1.Location = new System.Drawing.Point(28, 388);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(83, 29);
            this.label1.TabIndex = 101;
            this.label1.Text = "Job ID";
            // 
            // prdctidlbl
            // 
            this.prdctidlbl.AutoSize = true;
            this.prdctidlbl.Font = new System.Drawing.Font("Trebuchet MS", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.prdctidlbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.prdctidlbl.Location = new System.Drawing.Point(28, 327);
            this.prdctidlbl.Name = "prdctidlbl";
            this.prdctidlbl.Size = new System.Drawing.Size(130, 29);
            this.prdctidlbl.TabIndex = 100;
            this.prdctidlbl.Text = "Product ID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Trebuchet MS", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.label2.Location = new System.Drawing.Point(28, 455);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(172, 29);
            this.label2.TabIndex = 102;
            this.label2.Text = "Payment Type";
            // 
            // paymentcombobox
            // 
            this.paymentcombobox.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold);
            this.paymentcombobox.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.paymentcombobox.FormattingEnabled = true;
            this.paymentcombobox.Items.AddRange(new object[] {
            "Cash",
            "Card"});
            this.paymentcombobox.Location = new System.Drawing.Point(236, 454);
            this.paymentcombobox.Name = "paymentcombobox";
            this.paymentcombobox.Size = new System.Drawing.Size(220, 34);
            this.paymentcombobox.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Trebuchet MS", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.label3.Location = new System.Drawing.Point(28, 514);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(170, 29);
            this.label3.TabIndex = 104;
            this.label3.Text = "Payment Date";
            // 
            // datetime
            // 
            this.datetime.CalendarTrailingForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.datetime.Font = new System.Drawing.Font("Trebuchet MS", 13.8F, System.Drawing.FontStyle.Bold);
            this.datetime.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.datetime.Location = new System.Drawing.Point(236, 509);
            this.datetime.Name = "datetime";
            this.datetime.Size = new System.Drawing.Size(220, 34);
            this.datetime.TabIndex = 6;
            // 
            // amntlbl
            // 
            this.amntlbl.AutoSize = true;
            this.amntlbl.Font = new System.Drawing.Font("Trebuchet MS", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.amntlbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.amntlbl.Location = new System.Drawing.Point(28, 568);
            this.amntlbl.Name = "amntlbl";
            this.amntlbl.Size = new System.Drawing.Size(101, 29);
            this.amntlbl.TabIndex = 106;
            this.amntlbl.Text = "Amount";
            // 
            // Amnttextbox
            // 
            this.Amnttextbox.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Amnttextbox.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.Amnttextbox.Location = new System.Drawing.Point(236, 567);
            this.Amnttextbox.Multiline = true;
            this.Amnttextbox.Name = "Amnttextbox";
            this.Amnttextbox.Size = new System.Drawing.Size(220, 36);
            this.Amnttextbox.TabIndex = 7;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.panel5.Controls.Add(this.button3);
            this.panel5.Location = new System.Drawing.Point(1156, 700);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(127, 57);
            this.panel5.TabIndex = 14;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button3.Location = new System.Drawing.Point(22, 8);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(90, 40);
            this.button3.TabIndex = 15;
            this.button3.Text = "Next";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // btnrefresh
            // 
            this.btnrefresh.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(65)))), ((int)(((byte)(65)))));
            this.btnrefresh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnrefresh.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnrefresh.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnrefresh.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnrefresh.Location = new System.Drawing.Point(854, 538);
            this.btnrefresh.Name = "btnrefresh";
            this.btnrefresh.Size = new System.Drawing.Size(116, 40);
            this.btnrefresh.TabIndex = 14;
            this.btnrefresh.Text = "Refresh";
            this.btnrefresh.UseVisualStyleBackColor = false;
            this.btnrefresh.Click += new System.EventHandler(this.btnrefresh_Click);
            // 
            // Custmrcombobx
            // 
            this.Custmrcombobx.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold);
            this.Custmrcombobx.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.Custmrcombobx.FormattingEnabled = true;
            this.Custmrcombobx.Location = new System.Drawing.Point(236, 261);
            this.Custmrcombobx.Name = "Custmrcombobx";
            this.Custmrcombobx.Size = new System.Drawing.Size(220, 34);
            this.Custmrcombobx.TabIndex = 2;
            // 
            // prdctcombobx
            // 
            this.prdctcombobx.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold);
            this.prdctcombobx.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.prdctcombobx.FormattingEnabled = true;
            this.prdctcombobx.Location = new System.Drawing.Point(236, 322);
            this.prdctcombobx.Name = "prdctcombobx";
            this.prdctcombobx.Size = new System.Drawing.Size(220, 34);
            this.prdctcombobx.TabIndex = 3;
            // 
            // Payment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1282, 760);
            this.Controls.Add(this.prdctcombobx);
            this.Controls.Add(this.Custmrcombobx);
            this.Controls.Add(this.btnrefresh);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.Amnttextbox);
            this.Controls.Add(this.amntlbl);
            this.Controls.Add(this.datetime);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.paymentcombobox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Jobcombobx);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.prdctidlbl);
            this.Controls.Add(this.lblcstmr);
            this.Controls.Add(this.paymentidtxtbxtxbx);
            this.Controls.Add(this.paymentllbl);
            this.Controls.Add(this.datelbl);
            this.Controls.Add(this.tymlbl);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.trnstlbl);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Payment";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form9";
            this.Load += new System.EventHandler(this.Form9_Load);
            this.panel2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel5.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button minimzebtn;
        private System.Windows.Forms.Button exitbtn;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button hmbtn;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button Clearbtn;
        private System.Windows.Forms.Button btnupdate;
        private System.Windows.Forms.Button btnsearch;
        private System.Windows.Forms.Button btndelete;
        private System.Windows.Forms.Button Savebtn;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label trnstlbl;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label datelbl;
        private System.Windows.Forms.Label tymlbl;
        private System.Windows.Forms.TextBox paymentidtxtbxtxbx;
        private System.Windows.Forms.Label paymentllbl;
        private System.Windows.Forms.Label lblcstmr;
        private System.Windows.Forms.ComboBox Jobcombobx;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label prdctidlbl;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox paymentcombobox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DateTimePicker datetime;
        private System.Windows.Forms.Label amntlbl;
        private System.Windows.Forms.TextBox Amnttextbox;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button btnrefresh;
        private System.Windows.Forms.ComboBox Custmrcombobx;
        private System.Windows.Forms.ComboBox prdctcombobx;
    }
}