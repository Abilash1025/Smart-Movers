﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Smart_Mover
{
    public partial class Customer : Form
    {
        public Customer()
        {
            InitializeComponent();
            filldata();
        }
        static string connection = @"Data Source=ABI\SQLEXPRESS;Initial Catalog=SmartMovers;Integrated Security=True";

        string category, frstname, lastname, nic, address, email, messaging,id, mobileno, secondno;
        SqlConnection con = new SqlConnection(connection);
        private void exitbtn_Click(object sender, EventArgs e)
        {
            DialogResult dialogresult = MessageBox.Show("Are Your Going to exit?", "Exit Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Error);
            if (dialogresult == DialogResult.Yes)
            {
                Application.Exit();
            }

        }

        private void Form3_Load(object sender, EventArgs e)
        {
            timer1.Start();
            tymlbl.Text = DateTime.Now.ToLongTimeString();
            datelbl.Text = DateTime.Now.ToLongDateString();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Start();
            tymlbl.Text = DateTime.Now.ToLongTimeString();
        }

        private void hmbtn_Click(object sender, EventArgs e)
        {
            DialogResult dialogresult = MessageBox.Show("Are Your Sure?", "Configuration", MessageBoxButtons.YesNo, MessageBoxIcon.Error);
            if (dialogresult == DialogResult.Yes)
            {
                Menu f2 = new Menu();
                f2.Show();
                this.Hide();
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void Nxtbtn_Click(object sender, EventArgs e)
        {
            Product f4 = new Product();
            f4.Show();
            this.Hide();
        }
        private void filldata()
        {
            con.Open();

            SqlDataAdapter dtadpt = new SqlDataAdapter("select * from Customer", con);
            DataTable dttbl = new DataTable();
            dtadpt.Fill(dttbl);
            dataGridView1.DataSource = dttbl;

            con.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (customertxbx.Text == "" || firstnametxtbx.Text == "" || lstnametxtbx.Text == "" || NICtxbx.Text == "" ||
            addresstxbx.Text == "" || Mobilenotxbx.Text == "" || mailtxtbx.Text == "" )
            {
                MessageBox.Show("Please fill the all blanks","Alert");
            }
            else
            {

                id = customertxbx.Text;
                frstname = firstnametxtbx.Text;
                lastname = lstnametxtbx.Text;
                nic = NICtxbx.Text;
                address = addresstxbx.Text;
                mobileno = Mobilenotxbx.Text;
                secondno = secondnotxtbx.Text;
                email = mailtxtbx.Text;
                messaging = msgingcombobx.Text;

                con.Open();
                string insert = "insert into Customer values ('" + id + "','" + category + "','" + frstname + "','" + lastname + "','" +
                    nic + "','" + address + "','" + mobileno + "','" + secondno + "','" + email + "','" + messaging + "')";
                SqlCommand cmd = new SqlCommand(insert, con);
                cmd.ExecuteNonQuery();

                con.Close();

                MessageBox.Show("successfully saved in Customer database","Message");
            }
        }

        private void cat1_CheckedChanged(object sender, EventArgs e)
        {
            category = "Category 1";
        }

        private void cat2_CheckedChanged(object sender, EventArgs e)
        {
            category = "Category 2";
        }

        private void cat3_CheckedChanged(object sender, EventArgs e)
        {
            category = "Category 3";
        }

        private void btnrefresh_Click(object sender, EventArgs e)
        {
            filldata();
        }

        private void dataGridView1_DoubleClick(object sender, EventArgs e)
        {
            customertxbx.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            category = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            firstnametxtbx.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            lstnametxtbx.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            NICtxbx.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
            addresstxbx.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
            Mobilenotxbx.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();
            secondnotxtbx.Text = dataGridView1.CurrentRow.Cells[7].Value.ToString();
            mailtxtbx.Text = dataGridView1.CurrentRow.Cells[8].Value.ToString();
            msgingcombobx.SelectedText = dataGridView1.CurrentRow.Cells[9].Value.ToString();
            if (category == "Category 1")
            {
                cat1.Checked = true;
            }
            if (category == "Category 2")
            {
                cat2.Checked = true;
            }
            if (category == "Category 3")
            {
                cat3.Checked = true;
            }

        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            if (customertxbx.Text == "")
            {
                MessageBox.Show("Please fill the ID", "Alert");
            }
            else
            {
                id = customertxbx.Text;
                con.Open();
                string delete = "delete from Customer where Customer_id='" + id + "'";
                if (MessageBox.Show("Are you sure to delete data?", "confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                {
                    return;
                }
                else
                {
                    SqlCommand cmd = new SqlCommand(delete, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Successfully Deleted","Message");
                }
                con.Close();
            }
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            if (customertxbx.Text == "" || firstnametxtbx.Text == "" || lstnametxtbx.Text == "" || NICtxbx.Text == "" ||
            addresstxbx.Text == "" || Mobilenotxbx.Text == "" || mailtxtbx.Text == "")
            {
                MessageBox.Show("Please fill the all blanks", "Alert");
            }
            else
            {
                id = customertxbx.Text;
                frstname = firstnametxtbx.Text;
                lastname = lstnametxtbx.Text;
                nic = NICtxbx.Text;
                address = addresstxbx.Text;
                mobileno = Mobilenotxbx.Text;
                secondno = secondnotxtbx.Text;
                email = mailtxtbx.Text;
                messaging = msgingcombobx.Text;

                string update = "update Customer set Category ='" + category + "',First_name='" + frstname + "',Last_name='" +
                    lastname + "',Nic_no='" + nic + "',Address_='" + address + "',Mobile_no='" + mobileno + "',Second_no='" +
                    secondno + "',Email='" + email + "',Messaging='" + messaging + "' where Customer_id ='" + id + "'";
                if (MessageBox.Show("Are you going to update the Customer data?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                {
                    return;
                }
                else
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand(update, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Succesfully updated","Message");
                    con.Close();

                }
            }
        }

        private void btnsearch_Click(object sender, EventArgs e)
        {
            if (customertxbx.Text == "")
            {
                MessageBox.Show("Please fill the ID", "Alert");
            }
            else
            {
                id = customertxbx.Text;
                string search = "Select *from Customer  where Customer_id='" + id + "'";
                SqlCommand cmd = new SqlCommand(search, con);

                con.Open();
                SqlDataReader r = cmd.ExecuteReader();
                if (r.Read())
                {
                    category = r["Category"].ToString();
                    firstnametxtbx.Text = r["First_name"].ToString();
                    lstnametxtbx.Text = r["Last_name"].ToString();
                    NICtxbx.Text = r["Nic_no"].ToString();
                    addresstxbx.Text = r["Address_"].ToString();
                    Mobilenotxbx.Text = r["Mobile_no"].ToString();
                    secondnotxtbx.Text = r["Second_no"].ToString();
                    mailtxtbx.Text = r["Email"].ToString();
                    msgingcombobx.Text = r["Messaging"].ToString();
                    if (category == "Category 1")
                    {
                        cat1.Checked = true;
                    }
                    if (category == "Category 2")
                    {
                        cat2.Checked = true;
                    }
                    if (category == "Category 3")
                    {
                        cat3.Checked = true;
                    }

                    con.Close();
                }
                else
                {
                    MessageBox.Show("Invalid ID", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            customertxbx.Clear();
            cat1.Checked = false;
            cat2.Checked = false;
            cat3.Checked = false;
            firstnametxtbx.Clear();
            lstnametxtbx.Clear();
            NICtxbx.Clear();
            addresstxbx.Clear();
            Mobilenotxbx.Clear();
            secondnotxtbx.Clear();
            mailtxtbx.Clear();
            msgingcombobx.ResetText();
        }

        private void secondnotxtbx_Click(object sender, EventArgs e)
        {

        }

        private void mailtxtbx_Click(object sender, EventArgs e)
        {

        }

        private void secondnotxtbx_TextChanged(object sender, EventArgs e)
        {

        }
        }
    }

