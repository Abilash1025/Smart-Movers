﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Smart_Mover
{
    public partial class Job : Form
    {
        public Job()
        {
            InitializeComponent();
            fillcombobox();
            Fillcombobox();
            FillCombobox();
            filldata();
        }
        static string connection = @"Data Source=ABI\SQLEXPRESS;Initial Catalog=SmartMovers;Integrated Security=True";
        string jodid, startlocation, endlocation, cutomerid,transid, loadid;
        DateTime date;
        SqlConnection con = new SqlConnection(connection);
        private void exitbtn_Click(object sender, EventArgs e)
        {
            DialogResult dialogresult = MessageBox.Show("Are Your Going to exit?", "Exit Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Error);
            if (dialogresult == DialogResult.Yes)
            {
                Application.Exit();
            }

        }

        private void hmbtn_Click(object sender, EventArgs e)
        {
            DialogResult dialogresult = MessageBox.Show("Are Your Sure?", "Configuration", MessageBoxButtons.YesNo, MessageBoxIcon.Error);
            if (dialogresult == DialogResult.Yes)
            {
                Menu f2 = new Menu();
                f2.Show();
                this.Hide();
            }
        }

        private void exitbtn_Click_1(object sender, EventArgs e)
        {
            DialogResult dialogresult = MessageBox.Show("Are Your Going to exit?", "Exit Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Error);
            if (dialogresult == DialogResult.Yes)
            {
                Application.Exit();
            }

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Start();
            tymlbl.Text = DateTime.Now.ToLongTimeString();
        }

        private void Form6_Load(object sender, EventArgs e)
        {
            timer1.Start();
            tymlbl.Text = DateTime.Now.ToLongTimeString();
            datelbl.Text = DateTime.Now.ToLongDateString();
            cmbcstmnr.ResetText();
            cmbtransport.ResetText();
            cmbload.ResetText();
        }

        private void Nxtbtn_Click(object sender, EventArgs e)
        {
            Payment f9 = new Payment();
            f9.Show();
            this.Hide();
        }

        private void minimizebtn_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
        private void filldata()
        {
            con.Open();

            SqlDataAdapter dtadpt = new SqlDataAdapter("select * from Job", con);
            DataTable dttbl = new DataTable();
            dtadpt.Fill(dttbl);
            dataGridView1.DataSource = dttbl;

            con.Close();
        }
        private void fillcombobox()
        {
            SqlDataAdapter da = new SqlDataAdapter("Select Customer_id from Customer order by Customer_id desc", con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            cmbcstmnr.DataSource = dt;
            cmbcstmnr.DisplayMember = "Customer_id";
            cmbcstmnr.ValueMember = "Customer_id";



        }
        private void Fillcombobox()
        {
            SqlDataAdapter da = new SqlDataAdapter("Select Load_id from Load order by Load_id desc", con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            cmbload.DataSource = dt;
            cmbload.DisplayMember = "Load_id";
            cmbload.ValueMember = "Load_id";

        }
        private void FillCombobox()
        {
            SqlDataAdapter da = new SqlDataAdapter("Select Transport_id from Transport order by Transport_id desc", con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            cmbtransport.DataSource = dt;
            cmbtransport.DisplayMember = "Transport_id";
            cmbtransport.ValueMember = "Transport_id";

        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (jodidtxtbxtxbx.Text == "" || strtlocation.Text == "" || endloctiontxtbx.Text == "" || cmbcstmnr.Text == "" ||
            cmbtransport.Text == ""||cmbload.Text=="")
            {
                MessageBox.Show("Please fill the all blanks", "Alert");
            }
            else
            {

                jodid = jodidtxtbxtxbx.Text;
                startlocation = strtlocation.Text;
                endlocation = endloctiontxtbx.Text;
                date = datetime.Value.Date;
                cutomerid = cmbcstmnr.Text;
                transid = cmbtransport.Text;
                loadid = cmbload.Text;

                con.Open();
                string insert = "insert into Job values ('" + jodid + "','" + startlocation + "','"+endlocation +"','" + date + "','" + cutomerid + "','" +
                    transid + "','"+ loadid +"')";
                SqlCommand cmd = new SqlCommand(insert, con);
                cmd.ExecuteNonQuery();

                con.Close();

                MessageBox.Show("successfully saved in Job database", "Message");
            }
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            if (jodidtxtbxtxbx.Text == "" || strtlocation.Text == "" || endloctiontxtbx.Text == "" || cmbcstmnr.Text == "" ||
                cmbtransport.Text == "" || cmbload.Text == "")
            {
                MessageBox.Show("Please fill the all blanks", "Alert");
            }
            else
            {
                jodid = jodidtxtbxtxbx.Text;
                startlocation = strtlocation.Text;
                endlocation = endloctiontxtbx.Text;
                date = datetime.Value.Date;
                cutomerid = cmbcstmnr.Text;
                transid = cmbtransport.Text;
                loadid = cmbload.Text;


                string update = "update Job set Start_location ='" + startlocation + "',End_location='" + endlocation + "',Job_date='" +
                    date + "',Customer_id='" + cutomerid + "',Transport_id='"+ transid +"',Load_id='" + loadid + "' where Job_id ='" + jodid + "'";
                if (MessageBox.Show("Are you going to update the Job data?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                {
                    return;
                }
                else
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand(update, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Succesfully updated","Message");
                    con.Close();

                }
            }
        }

        private void btnsearch_Click(object sender, EventArgs e)
        {
            if (jodidtxtbxtxbx.Text == "" )
            {
                MessageBox.Show("Please enter the ID", "Alert");
            }
            else
            {
                jodid = jodidtxtbxtxbx.Text;
                string search = "Select *from Job where Job_id ='" + jodid + "'";
                SqlCommand cmd = new SqlCommand(search, con);

                con.Open();
                SqlDataReader r = cmd.ExecuteReader();
                if (r.Read())
                {
                    strtlocation.Text = r["Start_location"].ToString();
                    endloctiontxtbx.Text = r["End_location"].ToString();
                    datetime.Text = r["Job_date"].ToString();
                    cmbcstmnr.Text = r["Customer_id"].ToString();
                    cmbtransport.Text = r["Transport_id"].ToString();
                    cmbtransport.Text = r["Load_id"].ToString();
                                     
    
                    con.Close();
                }
                else
                {
                    MessageBox.Show("Invalid ID", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
            }
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            if (jodidtxtbxtxbx.Text == "")
            {
                MessageBox.Show("Please fill the ID", "Alert");
            }
            else
            {
                jodid = jodidtxtbxtxbx.Text;
                con.Open();
                string delete = "delete from Job where Job_id='" + jodid + "'";
                if (MessageBox.Show("Are you sure to delete data?", "confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                {
                    return;
                }
                else
                {
                    SqlCommand cmd = new SqlCommand(delete, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Successfully Deleted", "Message");
                }
                con.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            jodidtxtbxtxbx.Clear();
            strtlocation.Clear();
            endloctiontxtbx.Clear();
            datetime.ResetText();
            cmbcstmnr.ResetText();
            cmbtransport.ResetText();
            cmbload.ResetText();
        }

        private void btnrefresh_Click(object sender, EventArgs e)
        {
            filldata();
        }

        private void dataGridView1_DoubleClick(object sender, EventArgs e)
        {
            jodidtxtbxtxbx.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            strtlocation.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            endloctiontxtbx.Text=dataGridView1.CurrentRow.Cells[2].Value.ToString();
            datetime.Text=dataGridView1.CurrentRow.Cells[3].Value.ToString();
            cmbcstmnr.SelectedText=dataGridView1.CurrentRow.Cells[4].Value.ToString();
            cmbtransport.SelectedText = dataGridView1.CurrentRow.Cells[5].Value.ToString();
            cmbload.SelectedText = dataGridView1.CurrentRow.Cells[6].Value.ToString();
        }
    }
}
