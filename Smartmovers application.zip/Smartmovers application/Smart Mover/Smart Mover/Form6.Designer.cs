﻿namespace Smart_Mover
{
    partial class Job
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Job));
            this.clearbtn = new System.Windows.Forms.Panel();
            this.minimizebtn = new System.Windows.Forms.Button();
            this.exitbtn = new System.Windows.Forms.Button();
            this.Nxtbtn = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.hmbtn = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.btnupdate = new System.Windows.Forms.Button();
            this.btnsearch = new System.Windows.Forms.Button();
            this.btndelete = new System.Windows.Forms.Button();
            this.Savebtn = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.datelbl = new System.Windows.Forms.Label();
            this.tymlbl = new System.Windows.Forms.Label();
            this.endloctiontxtbx = new System.Windows.Forms.TextBox();
            this.jodidtxtbxtxbx = new System.Windows.Forms.TextBox();
            this.qntylbl = new System.Windows.Forms.Label();
            this.jblbl = new System.Windows.Forms.Label();
            this.typelbl = new System.Windows.Forms.Label();
            this.strtlocation = new System.Windows.Forms.TextBox();
            this.datetime = new System.Windows.Forms.DateTimePicker();
            this.mfdatelbl = new System.Windows.Forms.Label();
            this.cmbcstmnr = new System.Windows.Forms.ComboBox();
            this.custlbl = new System.Windows.Forms.Label();
            this.cmbtransport = new System.Windows.Forms.ComboBox();
            this.trnslbl = new System.Windows.Forms.Label();
            this.joblbl = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.panel5 = new System.Windows.Forms.Panel();
            this.btnrefresh = new System.Windows.Forms.Button();
            this.cmbload = new System.Windows.Forms.ComboBox();
            this.ldlbl = new System.Windows.Forms.Label();
            this.clearbtn.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // clearbtn
            // 
            this.clearbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.clearbtn.Controls.Add(this.minimizebtn);
            this.clearbtn.Controls.Add(this.exitbtn);
            this.clearbtn.Location = new System.Drawing.Point(1156, -4);
            this.clearbtn.Name = "clearbtn";
            this.clearbtn.Size = new System.Drawing.Size(127, 769);
            this.clearbtn.TabIndex = 15;
            // 
            // minimizebtn
            // 
            this.minimizebtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.minimizebtn.Font = new System.Drawing.Font("Cooper Black", 10.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.minimizebtn.ForeColor = System.Drawing.Color.White;
            this.minimizebtn.Location = new System.Drawing.Point(3, 15);
            this.minimizebtn.Name = "minimizebtn";
            this.minimizebtn.Size = new System.Drawing.Size(62, 52);
            this.minimizebtn.TabIndex = 16;
            this.minimizebtn.Text = "__";
            this.minimizebtn.UseVisualStyleBackColor = false;
            this.minimizebtn.Click += new System.EventHandler(this.minimizebtn_Click);
            // 
            // exitbtn
            // 
            this.exitbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.exitbtn.Font = new System.Drawing.Font("Trebuchet MS", 18F, System.Drawing.FontStyle.Bold);
            this.exitbtn.ForeColor = System.Drawing.Color.White;
            this.exitbtn.Location = new System.Drawing.Point(61, 15);
            this.exitbtn.Name = "exitbtn";
            this.exitbtn.Size = new System.Drawing.Size(62, 52);
            this.exitbtn.TabIndex = 17;
            this.exitbtn.Text = "x";
            this.exitbtn.UseVisualStyleBackColor = false;
            this.exitbtn.Click += new System.EventHandler(this.exitbtn_Click_1);
            // 
            // Nxtbtn
            // 
            this.Nxtbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.Nxtbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Nxtbtn.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Nxtbtn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Nxtbtn.Location = new System.Drawing.Point(22, 10);
            this.Nxtbtn.Name = "Nxtbtn";
            this.Nxtbtn.Size = new System.Drawing.Size(90, 40);
            this.Nxtbtn.TabIndex = 14;
            this.Nxtbtn.Text = "Next";
            this.Nxtbtn.UseVisualStyleBackColor = false;
            this.Nxtbtn.Click += new System.EventHandler(this.Nxtbtn_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(45)))), ((int)(((byte)(40)))));
            this.panel1.Controls.Add(this.hmbtn);
            this.panel1.Location = new System.Drawing.Point(0, -4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1283, 70);
            this.panel1.TabIndex = 14;
            // 
            // hmbtn
            // 
            this.hmbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(45)))), ((int)(((byte)(40)))));
            this.hmbtn.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hmbtn.ForeColor = System.Drawing.Color.White;
            this.hmbtn.Location = new System.Drawing.Point(3, 10);
            this.hmbtn.Name = "hmbtn";
            this.hmbtn.Size = new System.Drawing.Size(74, 52);
            this.hmbtn.TabIndex = 15;
            this.hmbtn.Text = "Home";
            this.hmbtn.UseVisualStyleBackColor = false;
            this.hmbtn.Click += new System.EventHandler(this.hmbtn_Click);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(30)))), ((int)(((byte)(40)))));
            this.panel4.Controls.Add(this.button2);
            this.panel4.Controls.Add(this.btnupdate);
            this.panel4.Controls.Add(this.btnsearch);
            this.panel4.Controls.Add(this.btndelete);
            this.panel4.Controls.Add(this.Savebtn);
            this.panel4.Location = new System.Drawing.Point(498, 153);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(154, 611);
            this.panel4.TabIndex = 7;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(30)))), ((int)(((byte)(40)))));
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Trebuchet MS", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.button2.Image = ((System.Drawing.Image)(resources.GetObject("button2.Image")));
            this.button2.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button2.Location = new System.Drawing.Point(0, 555);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(154, 52);
            this.button2.TabIndex = 11;
            this.button2.Text = "Clear";
            this.button2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnupdate
            // 
            this.btnupdate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(30)))), ((int)(((byte)(40)))));
            this.btnupdate.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnupdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnupdate.Font = new System.Drawing.Font("Trebuchet MS", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnupdate.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnupdate.Image = ((System.Drawing.Image)(resources.GetObject("btnupdate.Image")));
            this.btnupdate.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnupdate.Location = new System.Drawing.Point(0, 62);
            this.btnupdate.Name = "btnupdate";
            this.btnupdate.Size = new System.Drawing.Size(154, 52);
            this.btnupdate.TabIndex = 8;
            this.btnupdate.Text = "Update";
            this.btnupdate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnupdate.UseVisualStyleBackColor = false;
            this.btnupdate.Click += new System.EventHandler(this.btnupdate_Click);
            // 
            // btnsearch
            // 
            this.btnsearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(30)))), ((int)(((byte)(40)))));
            this.btnsearch.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnsearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnsearch.Font = new System.Drawing.Font("Trebuchet MS", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsearch.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnsearch.Image = ((System.Drawing.Image)(resources.GetObject("btnsearch.Image")));
            this.btnsearch.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnsearch.Location = new System.Drawing.Point(0, 132);
            this.btnsearch.Name = "btnsearch";
            this.btnsearch.Size = new System.Drawing.Size(154, 52);
            this.btnsearch.TabIndex = 9;
            this.btnsearch.Text = "Search";
            this.btnsearch.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnsearch.UseVisualStyleBackColor = false;
            this.btnsearch.Click += new System.EventHandler(this.btnsearch_Click);
            // 
            // btndelete
            // 
            this.btndelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(30)))), ((int)(((byte)(40)))));
            this.btndelete.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btndelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btndelete.Font = new System.Drawing.Font("Trebuchet MS", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndelete.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btndelete.Image = ((System.Drawing.Image)(resources.GetObject("btndelete.Image")));
            this.btndelete.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btndelete.Location = new System.Drawing.Point(0, 202);
            this.btndelete.Name = "btndelete";
            this.btndelete.Size = new System.Drawing.Size(154, 52);
            this.btndelete.TabIndex = 10;
            this.btndelete.Text = "Delete";
            this.btndelete.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btndelete.UseVisualStyleBackColor = false;
            this.btndelete.Click += new System.EventHandler(this.btndelete_Click);
            // 
            // Savebtn
            // 
            this.Savebtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(30)))), ((int)(((byte)(40)))));
            this.Savebtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.Savebtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Savebtn.Font = new System.Drawing.Font("Trebuchet MS", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Savebtn.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.Savebtn.Image = ((System.Drawing.Image)(resources.GetObject("Savebtn.Image")));
            this.Savebtn.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Savebtn.Location = new System.Drawing.Point(0, -1);
            this.Savebtn.Name = "Savebtn";
            this.Savebtn.Size = new System.Drawing.Size(154, 52);
            this.Savebtn.TabIndex = 7;
            this.Savebtn.Text = "Save";
            this.Savebtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Savebtn.UseVisualStyleBackColor = false;
            this.Savebtn.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(30)))), ((int)(((byte)(40)))));
            this.panel3.Location = new System.Drawing.Point(-1, 144);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1185, 10);
            this.panel3.TabIndex = 31;
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(657, 195);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(492, 327);
            this.dataGridView1.TabIndex = 51;
            this.dataGridView1.DoubleClick += new System.EventHandler(this.dataGridView1_DoubleClick);
            // 
            // datelbl
            // 
            this.datelbl.AutoSize = true;
            this.datelbl.Font = new System.Drawing.Font("Trebuchet MS", 13.8F, System.Drawing.FontStyle.Bold);
            this.datelbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.datelbl.Location = new System.Drawing.Point(821, 725);
            this.datelbl.Name = "datelbl";
            this.datelbl.Size = new System.Drawing.Size(65, 29);
            this.datelbl.TabIndex = 53;
            this.datelbl.Text = "Date";
            // 
            // tymlbl
            // 
            this.tymlbl.AutoSize = true;
            this.tymlbl.Font = new System.Drawing.Font("Trebuchet MS", 13.8F, System.Drawing.FontStyle.Bold);
            this.tymlbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.tymlbl.Location = new System.Drawing.Point(654, 725);
            this.tymlbl.Name = "tymlbl";
            this.tymlbl.Size = new System.Drawing.Size(69, 29);
            this.tymlbl.TabIndex = 52;
            this.tymlbl.Text = "Time";
            // 
            // endloctiontxtbx
            // 
            this.endloctiontxtbx.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.endloctiontxtbx.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.endloctiontxtbx.Location = new System.Drawing.Point(237, 315);
            this.endloctiontxtbx.Multiline = true;
            this.endloctiontxtbx.Name = "endloctiontxtbx";
            this.endloctiontxtbx.Size = new System.Drawing.Size(220, 36);
            this.endloctiontxtbx.TabIndex = 3;
            // 
            // jodidtxtbxtxbx
            // 
            this.jodidtxtbxtxbx.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jodidtxtbxtxbx.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.jodidtxtbxtxbx.Location = new System.Drawing.Point(237, 181);
            this.jodidtxtbxtxbx.Multiline = true;
            this.jodidtxtbxtxbx.Name = "jodidtxtbxtxbx";
            this.jodidtxtbxtxbx.Size = new System.Drawing.Size(220, 36);
            this.jodidtxtbxtxbx.TabIndex = 1;
            // 
            // qntylbl
            // 
            this.qntylbl.AutoSize = true;
            this.qntylbl.Font = new System.Drawing.Font("Trebuchet MS", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.qntylbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.qntylbl.Location = new System.Drawing.Point(29, 316);
            this.qntylbl.Name = "qntylbl";
            this.qntylbl.Size = new System.Drawing.Size(153, 29);
            this.qntylbl.TabIndex = 63;
            this.qntylbl.Text = "End location";
            // 
            // jblbl
            // 
            this.jblbl.AutoSize = true;
            this.jblbl.Font = new System.Drawing.Font("Trebuchet MS", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jblbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.jblbl.Location = new System.Drawing.Point(29, 182);
            this.jblbl.Name = "jblbl";
            this.jblbl.Size = new System.Drawing.Size(83, 29);
            this.jblbl.TabIndex = 62;
            this.jblbl.Text = "Job ID";
            // 
            // typelbl
            // 
            this.typelbl.AutoSize = true;
            this.typelbl.Font = new System.Drawing.Font("Trebuchet MS", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.typelbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.typelbl.Location = new System.Drawing.Point(29, 252);
            this.typelbl.Name = "typelbl";
            this.typelbl.Size = new System.Drawing.Size(172, 29);
            this.typelbl.TabIndex = 60;
            this.typelbl.Text = "Start Location";
            // 
            // strtlocation
            // 
            this.strtlocation.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.strtlocation.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.strtlocation.Location = new System.Drawing.Point(237, 245);
            this.strtlocation.Multiline = true;
            this.strtlocation.Name = "strtlocation";
            this.strtlocation.Size = new System.Drawing.Size(220, 36);
            this.strtlocation.TabIndex = 2;
            // 
            // datetime
            // 
            this.datetime.CalendarTrailingForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.datetime.Font = new System.Drawing.Font("Trebuchet MS", 13.8F, System.Drawing.FontStyle.Bold);
            this.datetime.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.datetime.Location = new System.Drawing.Point(237, 381);
            this.datetime.Name = "datetime";
            this.datetime.Size = new System.Drawing.Size(220, 34);
            this.datetime.TabIndex = 4;
            // 
            // mfdatelbl
            // 
            this.mfdatelbl.AutoSize = true;
            this.mfdatelbl.Font = new System.Drawing.Font("Trebuchet MS", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mfdatelbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.mfdatelbl.Location = new System.Drawing.Point(29, 377);
            this.mfdatelbl.Name = "mfdatelbl";
            this.mfdatelbl.Size = new System.Drawing.Size(113, 29);
            this.mfdatelbl.TabIndex = 67;
            this.mfdatelbl.Text = "Job Date";
            // 
            // cmbcstmnr
            // 
            this.cmbcstmnr.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold);
            this.cmbcstmnr.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.cmbcstmnr.FormattingEnabled = true;
            this.cmbcstmnr.Location = new System.Drawing.Point(237, 445);
            this.cmbcstmnr.Name = "cmbcstmnr";
            this.cmbcstmnr.Size = new System.Drawing.Size(220, 34);
            this.cmbcstmnr.TabIndex = 5;
            // 
            // custlbl
            // 
            this.custlbl.AutoSize = true;
            this.custlbl.Font = new System.Drawing.Font("Trebuchet MS", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.custlbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.custlbl.Location = new System.Drawing.Point(29, 450);
            this.custlbl.Name = "custlbl";
            this.custlbl.Size = new System.Drawing.Size(150, 29);
            this.custlbl.TabIndex = 69;
            this.custlbl.Text = "Customer ID";
            // 
            // cmbtransport
            // 
            this.cmbtransport.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold);
            this.cmbtransport.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.cmbtransport.FormattingEnabled = true;
            this.cmbtransport.Location = new System.Drawing.Point(237, 506);
            this.cmbtransport.Name = "cmbtransport";
            this.cmbtransport.Size = new System.Drawing.Size(220, 34);
            this.cmbtransport.TabIndex = 6;
            // 
            // trnslbl
            // 
            this.trnslbl.AutoSize = true;
            this.trnslbl.Font = new System.Drawing.Font("Trebuchet MS", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.trnslbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.trnslbl.Location = new System.Drawing.Point(29, 511);
            this.trnslbl.Name = "trnslbl";
            this.trnslbl.Size = new System.Drawing.Size(149, 29);
            this.trnslbl.TabIndex = 71;
            this.trnslbl.Text = "Transport ID";
            // 
            // joblbl
            // 
            this.joblbl.AutoSize = true;
            this.joblbl.BackColor = System.Drawing.Color.Transparent;
            this.joblbl.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.joblbl.Font = new System.Drawing.Font("Times New Roman", 36F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.joblbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(20)))), ((int)(((byte)(30)))));
            this.joblbl.Location = new System.Drawing.Point(486, 74);
            this.joblbl.Name = "joblbl";
            this.joblbl.Size = new System.Drawing.Size(119, 67);
            this.joblbl.TabIndex = 73;
            this.joblbl.Text = "Job";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.panel5.Controls.Add(this.Nxtbtn);
            this.panel5.Location = new System.Drawing.Point(1157, 705);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(127, 57);
            this.panel5.TabIndex = 13;
            // 
            // btnrefresh
            // 
            this.btnrefresh.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(65)))), ((int)(((byte)(65)))));
            this.btnrefresh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnrefresh.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnrefresh.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnrefresh.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnrefresh.Location = new System.Drawing.Point(866, 556);
            this.btnrefresh.Name = "btnrefresh";
            this.btnrefresh.Size = new System.Drawing.Size(116, 40);
            this.btnrefresh.TabIndex = 13;
            this.btnrefresh.Text = "Refresh";
            this.btnrefresh.UseVisualStyleBackColor = false;
            this.btnrefresh.Click += new System.EventHandler(this.btnrefresh_Click);
            // 
            // cmbload
            // 
            this.cmbload.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold);
            this.cmbload.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.cmbload.FormattingEnabled = true;
            this.cmbload.Location = new System.Drawing.Point(237, 572);
            this.cmbload.Name = "cmbload";
            this.cmbload.Size = new System.Drawing.Size(220, 34);
            this.cmbload.TabIndex = 7;
            // 
            // ldlbl
            // 
            this.ldlbl.AutoSize = true;
            this.ldlbl.Font = new System.Drawing.Font("Trebuchet MS", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ldlbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.ldlbl.Location = new System.Drawing.Point(29, 577);
            this.ldlbl.Name = "ldlbl";
            this.ldlbl.Size = new System.Drawing.Size(96, 29);
            this.ldlbl.TabIndex = 75;
            this.ldlbl.Text = "Load ID";
            // 
            // Job
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1282, 760);
            this.ControlBox = false;
            this.Controls.Add(this.cmbload);
            this.Controls.Add(this.ldlbl);
            this.Controls.Add(this.btnrefresh);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.joblbl);
            this.Controls.Add(this.cmbtransport);
            this.Controls.Add(this.trnslbl);
            this.Controls.Add(this.cmbcstmnr);
            this.Controls.Add(this.custlbl);
            this.Controls.Add(this.datetime);
            this.Controls.Add(this.mfdatelbl);
            this.Controls.Add(this.strtlocation);
            this.Controls.Add(this.endloctiontxtbx);
            this.Controls.Add(this.jodidtxtbxtxbx);
            this.Controls.Add(this.qntylbl);
            this.Controls.Add(this.jblbl);
            this.Controls.Add(this.typelbl);
            this.Controls.Add(this.datelbl);
            this.Controls.Add(this.tymlbl);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.clearbtn);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximumSize = new System.Drawing.Size(1300, 807);
            this.Name = "Job";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form6";
            this.Load += new System.EventHandler(this.Form6_Load);
            this.clearbtn.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel5.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel clearbtn;
        private System.Windows.Forms.Button exitbtn;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button hmbtn;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btnupdate;
        private System.Windows.Forms.Button btnsearch;
        private System.Windows.Forms.Button btndelete;
        private System.Windows.Forms.Button Savebtn;
        private System.Windows.Forms.Button minimizebtn;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label datelbl;
        private System.Windows.Forms.Label tymlbl;
        private System.Windows.Forms.Button Nxtbtn;
        private System.Windows.Forms.TextBox endloctiontxtbx;
        private System.Windows.Forms.TextBox jodidtxtbxtxbx;
        private System.Windows.Forms.Label qntylbl;
        private System.Windows.Forms.Label jblbl;
        private System.Windows.Forms.Label typelbl;
        private System.Windows.Forms.TextBox strtlocation;
        private System.Windows.Forms.DateTimePicker datetime;
        private System.Windows.Forms.Label mfdatelbl;
        private System.Windows.Forms.ComboBox cmbcstmnr;
        private System.Windows.Forms.Label custlbl;
        private System.Windows.Forms.ComboBox cmbtransport;
        private System.Windows.Forms.Label trnslbl;
        private System.Windows.Forms.Label joblbl;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button btnrefresh;
        private System.Windows.Forms.ComboBox cmbload;
        private System.Windows.Forms.Label ldlbl;



    }
}