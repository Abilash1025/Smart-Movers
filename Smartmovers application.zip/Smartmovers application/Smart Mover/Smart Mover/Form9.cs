﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Smart_Mover
{
    public partial class Payment : Form
    {
        static string connection = @"Data Source=ABI\SQLEXPRESS;Initial Catalog=SmartMovers;Integrated Security=True";
        string paymentid, customerid, prductid, Jobid, paymnttype, paymntdate, amount;
        SqlConnection con = new SqlConnection(connection);
        public Payment()
        {
            InitializeComponent();
            fillcombobox();
            filldata();
        }

        private void Form9_Load(object sender, EventArgs e)
        {
            timer1.Start();
            tymlbl.Text = DateTime.Now.ToLongTimeString();
            datelbl.Text = DateTime.Now.ToLongDateString();
            Custmrcombobx.ResetText();
            prdctcombobx.ResetText();
            Jobcombobx.ResetText();
        }

        private void hmbtn_Click(object sender, EventArgs e)
        {
            DialogResult dialogresult = MessageBox.Show("Are Your Sure?", "Configuration", MessageBoxButtons.YesNo, MessageBoxIcon.Error);
            if (dialogresult == DialogResult.Yes)
            {
                Menu f2 = new Menu();
                f2.Show();
                this.Hide();
            }
        }

        private void minimzebtn_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void exitbtn_Click(object sender, EventArgs e)
        {
            DialogResult dialogresult = MessageBox.Show("Are Your Going to exit?", "Exit Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Error);
            if (dialogresult == DialogResult.Yes)
            {
                Application.Exit();
            }

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Start();
            tymlbl.Text = DateTime.Now.ToLongTimeString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Record f10 = new Record();
            f10.Show();
            this.Hide();
        }
        private void filldata()
        {
            con.Open();

            SqlDataAdapter dtadpt = new SqlDataAdapter("select * from Payment", con);
            DataTable dttbl = new DataTable();
            dtadpt.Fill(dttbl);
            dataGridView1.DataSource = dttbl;

            con.Close();
        }
        private void fillcombobox()
        {
            SqlDataAdapter da = new SqlDataAdapter("Select Customer_id from Customer order by Customer_id desc", con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            Custmrcombobx.DataSource = dt;
            Custmrcombobx.DisplayMember = "Customer_id";
            Custmrcombobx.ValueMember = "Customer_id";

            SqlDataAdapter ds = new SqlDataAdapter("Select  Product_id from Product order by Product_id desc", con);
            DataTable dq = new DataTable();
            ds.Fill(dq);
            prdctcombobx.DataSource = dq;
            prdctcombobx.DisplayMember = "Product_id";
            prdctcombobx.ValueMember = "Product_id";

            SqlDataAdapter de = new SqlDataAdapter("Select Job_id from Job order by Job_id desc", con);
            DataTable dy = new DataTable();
            de.Fill(dy);
            Jobcombobx.DataSource = dy;
            Jobcombobx.DisplayMember = "Job_id";
            Jobcombobx.ValueMember = "Job_id";


        }
        private void Savebtn_Click(object sender, EventArgs e)
        {
            if (paymentidtxtbxtxbx.Text == "" || Custmrcombobx.Text == "" || prdctcombobx.Text == "" || Jobcombobx.Text == "" ||
paymentcombobox.Text == "" || datetime.Text == "" || Amnttextbox.Text == "")
            {
                MessageBox.Show("Please fill the all blanks", "Alert");
            }
            else
            {
                paymentid = paymentidtxtbxtxbx.Text;
                customerid = Custmrcombobx.Text;
                prductid = prdctcombobx.Text;
                Jobid = Jobcombobx.Text;
                paymnttype = paymentcombobox.Text;
                paymntdate = datetime.Text;
                amount = Amnttextbox.Text;


                con.Open();
                string insert = "insert into Payment values ('" + paymentid + "','" + customerid + "','" + prductid + "','" +
                    Jobid + "','" + paymnttype + "','" + paymntdate + "','" + amount + "')";
                SqlCommand cmd = new SqlCommand(insert, con);
                cmd.ExecuteNonQuery();

                con.Close();

                MessageBox.Show("successfully saved in Payment database", "Message");
            }
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            if (paymentidtxtbxtxbx.Text == "" || Custmrcombobx.Text == "" || prdctcombobx.Text == "" || Jobcombobx.Text == "" ||
               paymentcombobox.Text == "" || datetime.Text == "" || Amnttextbox.Text == "")
            {
                MessageBox.Show("Please fill the all blanks", "Alert");
            }
            else
            {
                paymentid = paymentidtxtbxtxbx.Text;
                customerid = Custmrcombobx.Text;
                prductid = prdctcombobx.Text;
                Jobid = Jobcombobx.Text;
                paymnttype = paymentcombobox.Text;
                paymntdate = datetime.Text;
                amount = Amnttextbox.Text;

                string update = "update Payment set Customer_id ='" + customerid + "',Product_id='" + prductid + "',Job_id='" +
   Jobid + "',Payment_type='" + paymnttype + "',Payment_date='" + paymntdate + "',Amount='" + amount + "' where Payment_id ='" + paymentid + "'";
                if (MessageBox.Show("Are you going to update the Payment data?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                {
                    return;
                }
                else
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand(update, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Succesfully updated", "Message");
                    con.Close();

                }
            }
        }

        private void btnsearch_Click(object sender, EventArgs e)
        {
            if (paymentidtxtbxtxbx.Text == "")
            {
                MessageBox.Show("Please fill the ID", "Alert");
            }
            else
            {
                paymentid = paymentidtxtbxtxbx.Text;
                string search = "Select *from Payment  where Payment_id='" + paymentid + "'";
                SqlCommand cmd = new SqlCommand(search, con);

                con.Open();
                SqlDataReader r = cmd.ExecuteReader();
                if (r.Read())
                {
                    paymentidtxtbxtxbx.Text = r["Payment_id"].ToString();
                    Custmrcombobx.Text = r["Customer_id"].ToString();
                    prdctcombobx.Text = r["Product_id"].ToString();
                    Jobcombobx.Text = r["Job_id"].ToString();
                    paymentcombobox.Text = r["Payment_type"].ToString();
                    datetime.Text = r["Payment_date"].ToString();
                    Amnttextbox.Text = r["Amount"].ToString();


                    con.Close();
                }
                else
                {
                    MessageBox.Show("Invalid ID", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
            }
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            if (paymentidtxtbxtxbx.Text == "")
            {
                MessageBox.Show("Please fill the ID", "Alert");
            }
            else
            {
                paymentid = paymentidtxtbxtxbx.Text;
                con.Open();
                string delete = "delete from Payment where Payment_id='" + paymentid + "'";
                if (MessageBox.Show("Are you sure to delete data?", "confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                {
                    return;
                }
                else
                {
                    SqlCommand cmd = new SqlCommand(delete, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Successfully Deleted", "Message");
                }
                con.Close();
            }
        }

        private void Clearbtn_Click(object sender, EventArgs e)
        {
            paymentidtxtbxtxbx.Clear();
            Custmrcombobx.ResetText();
            prdctcombobx.ResetText();
            Jobcombobx.ResetText();
            paymentcombobox.ResetText();
            datetime.ResetText();
            Amnttextbox.Clear();
        }

        private void dataGridView1_DoubleClick(object sender, EventArgs e)
        {
            paymentidtxtbxtxbx.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            Custmrcombobx.SelectedText = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            prdctcombobx.SelectedText = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            Jobcombobx.SelectedText = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            paymentcombobox.SelectedText = dataGridView1.CurrentRow.Cells[4].Value.ToString();
            datetime.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
            Amnttextbox.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();

        }

        private void btnrefresh_Click(object sender, EventArgs e)
        {
            filldata();
        }
    }
}