﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace Smart_Mover
{
    public partial class Depot : Form
    {
        public Depot()
        {
            InitializeComponent();
            filldata();

        }
        static string connection = @"Data Source=ABI\SQLEXPRESS;Initial Catalog=SmartMovers;Integrated Security=True";
        SqlConnection con = new SqlConnection(connection);
        string depotid, region;
        private void exitbtn_Click(object sender, EventArgs e)
        {
            DialogResult dialogresult = MessageBox.Show("Are Your Going to exit?", "Exit Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Error);
            if (dialogresult == DialogResult.Yes)
            {
                Application.Exit();
            }

        }

        private void hmbtn_Click(object sender, EventArgs e)
        {
            DialogResult dialogresult = MessageBox.Show("Are Your Sure?", "Configuration", MessageBoxButtons.YesNo, MessageBoxIcon.Error);
            if (dialogresult == DialogResult.Yes)
            {
                Menu f2 = new Menu();
                f2.Show();
                this.Hide();
            }
        }

        private void exitbtn_Click_1(object sender, EventArgs e)
        {
            DialogResult dialogresult = MessageBox.Show("Are Your Going to exit?", "Exit Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Error);
            if (dialogresult == DialogResult.Yes)
            {
                Application.Exit();
            }

        }

        private void Form7_Load(object sender, EventArgs e)
        {
            timer1.Start();
            tymlbl.Text = DateTime.Now.ToLongTimeString();
            datelbl.Text = DateTime.Now.ToLongDateString();

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Start();
            tymlbl.Text = DateTime.Now.ToLongTimeString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void Nxtbtn_Click(object sender, EventArgs e)
        {
            Transport f8 = new Transport();
            f8.Show();
            this.Hide();
        }
        private void filldata()
        {
            con.Open();

            SqlDataAdapter dtadpt = new SqlDataAdapter("select * from Depot", con);
            DataTable dttbl = new DataTable();
            dtadpt.Fill(dttbl);
            dataGridView1.DataSource = dttbl;

            con.Close();
        }



        private void Savebtn_Click(object sender, EventArgs e)
        {
            if (depottidtxtbxtxbx.Text == "" || Regioncmb.Text == "" )
            {
                MessageBox.Show("Please fill the all blanks", "Alert");
            }
            else
            {
                depotid = depottidtxtbxtxbx.Text;
                region = Regioncmb.Text;


                con.Open();
                string insert = "insert into Depot values ('" + depotid + "','" + region + "')";
                SqlCommand cmd = new SqlCommand(insert, con);
                cmd.ExecuteNonQuery();

                con.Close();

                MessageBox.Show("successfully saved in Depot database", "Message");
            }


        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            if (depottidtxtbxtxbx.Text == "" || Regioncmb.Text == "" )
            {
                MessageBox.Show("Please fill the all blanks", "Alert");
            }
            else
            {
                depotid = depottidtxtbxtxbx.Text;

                string update = "update Depot set Region ='" + region + "' where Depot_id ='" + depotid + "'";
                if (MessageBox.Show("Are you going to update the Depot data?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                {
                    return;
                }
                else
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand(update, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Succesfully updated", "Message");
                    con.Close();

                }
            }

        }

        private void btnsearch_Click(object sender, EventArgs e)
        {
            if (depottidtxtbxtxbx.Text == "")
            {
                MessageBox.Show("Please fill the all blanks", "Alert");
            }
            else
            {
                depotid = depottidtxtbxtxbx.Text;
                string search = "Select * from Depot  where Depot_id='" + depotid + "'";
                SqlCommand cmd = new SqlCommand(search, con);

                con.Open();
                SqlDataReader r = cmd.ExecuteReader();
                
                if (r.Read())
                {
                    Regioncmb.Text = r["Region"].ToString();
                    con.Close();
                    
                }
                else
                {
                    MessageBox.Show("Invalid ID", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
            }
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            if (depottidtxtbxtxbx.Text == "")
            {
                MessageBox.Show("Please fill the all blanks", "Alert");
            }
            else
            {
                depotid = depottidtxtbxtxbx.Text;
                con.Open();
                string delete = "delete from Depot where Depot_id='" + depotid + "'";
                if (MessageBox.Show("Are you sure to delete data?", "confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                {
                    return;
                }
                else
                {
                    SqlCommand cmd = new SqlCommand(delete, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Successfully Deleted", "Message");
                }
                con.Close();
            }
        }

        private void Clearbtn_Click(object sender, EventArgs e)
        {
            depottidtxtbxtxbx.Clear();
            Regioncmb.ResetText();

        }

        private void dataGridView1_DoubleClick(object sender, EventArgs e)
        {

            depottidtxtbxtxbx.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            Regioncmb.SelectedText = dataGridView1.CurrentRow.Cells[1].Value.ToString();

        }

        private void btnrefresh_Click(object sender, EventArgs e)
        {
            filldata();
        }

        private void regiontxtbx_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
        
      
    


