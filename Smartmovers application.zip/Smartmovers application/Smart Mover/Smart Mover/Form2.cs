﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Smart_Mover
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();
        }

        private void exitbtn_Click(object sender, EventArgs e)
        {
            DialogResult dialogresult = MessageBox.Show("Are Your Going to exit?", "Exit Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Error);
            if (dialogresult == DialogResult.Yes)
            {
                Application.Exit();
            }


        }

        private void btntransport_Click(object sender, EventArgs e)
        {

        }

        private void Menu_Load(object sender, EventArgs e)
        {
            timer1.Start();
            tymlbl.Text = DateTime.Now.ToLongTimeString();
            datelbl.Text = DateTime.Now.ToLongDateString();
        }

        private void btncustomer_Click(object sender, EventArgs e)
        {
            Customer f3 = new Customer();
            f3.Show();
            this.Hide();
        }

        private void hmbtn_Click(object sender, EventArgs e)
        {
          DialogResult dialogresult=  MessageBox.Show("Are Your Sure?", "Configuration", MessageBoxButtons.YesNo, MessageBoxIcon.Error);
          if (dialogresult == DialogResult.Yes)
          {
              front f11 = new front();
              f11.Show();
              this.Hide();
          }



        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void btnproduct_Click(object sender, EventArgs e)
        {
            Product f4 = new Product();
            f4.Show();
            this.Hide();
        }

        private void btnload_Click(object sender, EventArgs e)
        {
            Load f5 = new Load();
            f5.Show();
            this.Hide();
        }

        private void btnjob_Click(object sender, EventArgs e)
        {
            Job f6 = new Job();
            f6.Show();
            this.Hide();
        }

        private void btndepot_Click(object sender, EventArgs e)
        {
            Depot f7 = new Depot();
            f7.Show();
            this.Hide();
        }

        private void btntransport_Click_1(object sender, EventArgs e)
        {
            Transport f8 = new Transport();
            f8.Show();
            this.Hide();
        }

        private void btnpayment_Click(object sender, EventArgs e)
        {
            Payment f9 = new Payment();
            f9.Show();
            this.Hide();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Start();
            tymlbl.Text = DateTime.Now.ToLongTimeString();
        }

        private void btnrecrds_Click(object sender, EventArgs e)
        {
            Record f10 = new Record();
            f10.Show();
            this.Hide();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
