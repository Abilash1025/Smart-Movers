﻿namespace Smart_Mover
{
    partial class userrecord
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnpayment = new System.Windows.Forms.Button();
            this.btndepot = new System.Windows.Forms.Button();
            this.btnjob = new System.Windows.Forms.Button();
            this.btntransport = new System.Windows.Forms.Button();
            this.btnload = new System.Windows.Forms.Button();
            this.btnproduct = new System.Windows.Forms.Button();
            this.btncustomer = new System.Windows.Forms.Button();
            this.Recordlbl = new System.Windows.Forms.Label();
            this.datelbl = new System.Windows.Forms.Label();
            this.tymlbl = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.hmbtn = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.minimzebtn = new System.Windows.Forms.Button();
            this.exitbtn = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnpayment
            // 
            this.btnpayment.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(25)))), ((int)(((byte)(45)))));
            this.btnpayment.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnpayment.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnpayment.ForeColor = System.Drawing.Color.White;
            this.btnpayment.Location = new System.Drawing.Point(0, 671);
            this.btnpayment.Name = "btnpayment";
            this.btnpayment.Size = new System.Drawing.Size(321, 94);
            this.btnpayment.TabIndex = 82;
            this.btnpayment.Text = "Payments";
            this.btnpayment.UseVisualStyleBackColor = false;
            this.btnpayment.Click += new System.EventHandler(this.btnpayment_Click);
            // 
            // btndepot
            // 
            this.btndepot.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(25)))), ((int)(((byte)(45)))));
            this.btndepot.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btndepot.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndepot.ForeColor = System.Drawing.Color.White;
            this.btndepot.Location = new System.Drawing.Point(0, 431);
            this.btndepot.Name = "btndepot";
            this.btndepot.Size = new System.Drawing.Size(321, 85);
            this.btndepot.TabIndex = 80;
            this.btndepot.Text = "Depot";
            this.btndepot.UseVisualStyleBackColor = false;
            this.btndepot.Click += new System.EventHandler(this.btndepot_Click);
            // 
            // btnjob
            // 
            this.btnjob.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(25)))), ((int)(((byte)(45)))));
            this.btnjob.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnjob.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnjob.ForeColor = System.Drawing.Color.White;
            this.btnjob.Location = new System.Drawing.Point(0, 590);
            this.btnjob.Name = "btnjob";
            this.btnjob.Size = new System.Drawing.Size(321, 85);
            this.btnjob.TabIndex = 79;
            this.btnjob.Text = "Job";
            this.btnjob.UseVisualStyleBackColor = false;
            this.btnjob.Click += new System.EventHandler(this.btnjob_Click);
            // 
            // btntransport
            // 
            this.btntransport.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(25)))), ((int)(((byte)(45)))));
            this.btntransport.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btntransport.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btntransport.ForeColor = System.Drawing.Color.White;
            this.btntransport.Location = new System.Drawing.Point(0, 509);
            this.btntransport.Name = "btntransport";
            this.btntransport.Size = new System.Drawing.Size(321, 85);
            this.btntransport.TabIndex = 81;
            this.btntransport.Text = "Transport";
            this.btntransport.UseVisualStyleBackColor = false;
            this.btntransport.Click += new System.EventHandler(this.btntransport_Click);
            // 
            // btnload
            // 
            this.btnload.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(25)))), ((int)(((byte)(45)))));
            this.btnload.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnload.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnload.ForeColor = System.Drawing.Color.White;
            this.btnload.Location = new System.Drawing.Point(0, 346);
            this.btnload.Name = "btnload";
            this.btnload.Size = new System.Drawing.Size(321, 85);
            this.btnload.TabIndex = 78;
            this.btnload.Text = "Load";
            this.btnload.UseVisualStyleBackColor = false;
            this.btnload.Click += new System.EventHandler(this.btnload_Click);
            // 
            // btnproduct
            // 
            this.btnproduct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(25)))), ((int)(((byte)(45)))));
            this.btnproduct.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnproduct.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnproduct.ForeColor = System.Drawing.Color.White;
            this.btnproduct.Location = new System.Drawing.Point(0, 264);
            this.btnproduct.Name = "btnproduct";
            this.btnproduct.Size = new System.Drawing.Size(321, 85);
            this.btnproduct.TabIndex = 77;
            this.btnproduct.Text = "Product";
            this.btnproduct.UseVisualStyleBackColor = false;
            this.btnproduct.Click += new System.EventHandler(this.btnproduct_Click);
            // 
            // btncustomer
            // 
            this.btncustomer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(25)))), ((int)(((byte)(45)))));
            this.btncustomer.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btncustomer.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncustomer.ForeColor = System.Drawing.Color.White;
            this.btncustomer.Location = new System.Drawing.Point(0, 181);
            this.btncustomer.Name = "btncustomer";
            this.btncustomer.Size = new System.Drawing.Size(321, 85);
            this.btncustomer.TabIndex = 76;
            this.btncustomer.Text = "Customer";
            this.btncustomer.UseVisualStyleBackColor = false;
            this.btncustomer.Click += new System.EventHandler(this.btncustomer_Click);
            // 
            // Recordlbl
            // 
            this.Recordlbl.AutoSize = true;
            this.Recordlbl.BackColor = System.Drawing.Color.Transparent;
            this.Recordlbl.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Recordlbl.Font = new System.Drawing.Font("Times New Roman", 36F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Recordlbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(20)))), ((int)(((byte)(30)))));
            this.Recordlbl.Location = new System.Drawing.Point(519, 74);
            this.Recordlbl.Name = "Recordlbl";
            this.Recordlbl.Size = new System.Drawing.Size(206, 67);
            this.Recordlbl.TabIndex = 88;
            this.Recordlbl.Text = "Record";
            // 
            // datelbl
            // 
            this.datelbl.AutoSize = true;
            this.datelbl.Font = new System.Drawing.Font("Trebuchet MS", 13.8F, System.Drawing.FontStyle.Bold);
            this.datelbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(25)))), ((int)(((byte)(35)))));
            this.datelbl.Location = new System.Drawing.Point(789, 718);
            this.datelbl.Name = "datelbl";
            this.datelbl.Size = new System.Drawing.Size(65, 29);
            this.datelbl.TabIndex = 87;
            this.datelbl.Text = "Date";
            // 
            // tymlbl
            // 
            this.tymlbl.AutoSize = true;
            this.tymlbl.Font = new System.Drawing.Font("Trebuchet MS", 13.8F, System.Drawing.FontStyle.Bold);
            this.tymlbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(25)))), ((int)(((byte)(35)))));
            this.tymlbl.Location = new System.Drawing.Point(622, 718);
            this.tymlbl.Name = "tymlbl";
            this.tymlbl.Size = new System.Drawing.Size(69, 29);
            this.tymlbl.TabIndex = 86;
            this.tymlbl.Text = "Time";
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(328, 195);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(824, 495);
            this.dataGridView1.TabIndex = 85;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(25)))), ((int)(((byte)(35)))));
            this.panel1.Controls.Add(this.hmbtn);
            this.panel1.Location = new System.Drawing.Point(-1, -4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1283, 70);
            this.panel1.TabIndex = 83;
            // 
            // hmbtn
            // 
            this.hmbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(25)))), ((int)(((byte)(35)))));
            this.hmbtn.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hmbtn.ForeColor = System.Drawing.Color.White;
            this.hmbtn.Location = new System.Drawing.Point(3, 15);
            this.hmbtn.Name = "hmbtn";
            this.hmbtn.Size = new System.Drawing.Size(91, 52);
            this.hmbtn.TabIndex = 9;
            this.hmbtn.Text = "Logout";
            this.hmbtn.UseVisualStyleBackColor = false;
            this.hmbtn.Click += new System.EventHandler(this.hmbtn_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(25)))), ((int)(((byte)(35)))));
            this.panel3.Location = new System.Drawing.Point(0, 149);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1185, 33);
            this.panel3.TabIndex = 84;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(15)))), ((int)(((byte)(35)))));
            this.panel2.Controls.Add(this.minimzebtn);
            this.panel2.Controls.Add(this.exitbtn);
            this.panel2.Location = new System.Drawing.Point(1156, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(127, 769);
            this.panel2.TabIndex = 89;
            // 
            // minimzebtn
            // 
            this.minimzebtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(15)))), ((int)(((byte)(35)))));
            this.minimzebtn.Font = new System.Drawing.Font("Cooper Black", 10.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.minimzebtn.ForeColor = System.Drawing.Color.White;
            this.minimzebtn.Location = new System.Drawing.Point(4, 18);
            this.minimzebtn.Name = "minimzebtn";
            this.minimzebtn.Size = new System.Drawing.Size(62, 52);
            this.minimzebtn.TabIndex = 9;
            this.minimzebtn.Text = "__";
            this.minimzebtn.UseVisualStyleBackColor = false;
            this.minimzebtn.Click += new System.EventHandler(this.minimzebtn_Click);
            // 
            // exitbtn
            // 
            this.exitbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(15)))), ((int)(((byte)(35)))));
            this.exitbtn.Font = new System.Drawing.Font("Trebuchet MS", 18F, System.Drawing.FontStyle.Bold);
            this.exitbtn.ForeColor = System.Drawing.Color.White;
            this.exitbtn.Location = new System.Drawing.Point(63, 18);
            this.exitbtn.Name = "exitbtn";
            this.exitbtn.Size = new System.Drawing.Size(62, 52);
            this.exitbtn.TabIndex = 10;
            this.exitbtn.Text = "x";
            this.exitbtn.UseVisualStyleBackColor = false;
            this.exitbtn.Click += new System.EventHandler(this.exitbtn_Click);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // userrecord
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1282, 760);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.btnpayment);
            this.Controls.Add(this.btndepot);
            this.Controls.Add(this.btnjob);
            this.Controls.Add(this.btntransport);
            this.Controls.Add(this.btnload);
            this.Controls.Add(this.btnproduct);
            this.Controls.Add(this.btncustomer);
            this.Controls.Add(this.Recordlbl);
            this.Controls.Add(this.datelbl);
            this.Controls.Add(this.tymlbl);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel3);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "userrecord";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form13";
            this.Load += new System.EventHandler(this.Form13_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnpayment;
        private System.Windows.Forms.Button btndepot;
        private System.Windows.Forms.Button btnjob;
        private System.Windows.Forms.Button btntransport;
        private System.Windows.Forms.Button btnload;
        private System.Windows.Forms.Button btnproduct;
        private System.Windows.Forms.Button btncustomer;
        private System.Windows.Forms.Label Recordlbl;
        private System.Windows.Forms.Label datelbl;
        private System.Windows.Forms.Label tymlbl;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button minimzebtn;
        private System.Windows.Forms.Button exitbtn;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button hmbtn;

    }
}