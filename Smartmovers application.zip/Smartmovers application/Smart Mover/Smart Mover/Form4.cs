﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Smart_Mover
{
    public partial class Product : Form
    {
        public Product()
        {
            InitializeComponent();
            filldata();
        }
        static string connection = @"Data Source=ABI\SQLEXPRESS;Initial Catalog=SmartMovers;Integrated Security=True";
        SqlConnection con = new SqlConnection(connection);
        string prdctname, type, quantity,id;
        DateTime manufastrdate, expirydate;

        private void exitbtn_Click(object sender, EventArgs e)
        {
            DialogResult dialogresult = MessageBox.Show("Are Your Going to exit?", "Exit Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Error);
            if (dialogresult == DialogResult.Yes)
            {
                Application.Exit();
            }

        }

        private void hmbtn_Click(object sender, EventArgs e)
        {
            DialogResult dialogresult = MessageBox.Show("Are Your Sure?", "Configuration", MessageBoxButtons.YesNo, MessageBoxIcon.Error);
            if (dialogresult == DialogResult.Yes)
            {
                Menu f2 = new Menu();
                f2.Show();
                this.Hide();
            }
        }

        private void exitbtn_Click_1(object sender, EventArgs e)
        {
            DialogResult dialogresult = MessageBox.Show("Are Your Going to exit?", "Exit Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Error);
            if (dialogresult == DialogResult.Yes)
            {
                Application.Exit();
            }

        }

        private void Form4_Load(object sender, EventArgs e)
        {
            timer1.Start();
            tymlbl.Text = DateTime.Now.ToLongTimeString();
            datelbl.Text = DateTime.Now.ToLongDateString();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Start();
            tymlbl.Text = DateTime.Now.ToLongTimeString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void Nxtbtn_Click(object sender, EventArgs e)
        {
            Load f5 = new Load();
            f5.Show();
            this.Hide();
        }

        private void prdctidlbl_Click(object sender, EventArgs e)
        {

        }

        private void prdctidtxtbxtxbx_TextChanged(object sender, EventArgs e)
        {

        }
        private void filldata()
        {
            con.Open();

            SqlDataAdapter dtadpt = new SqlDataAdapter("select * from Product", con);
            DataTable dttbl = new DataTable();
            dtadpt.Fill(dttbl);
            dataGridView1.DataSource = dttbl;

            con.Close();
        }
        private void Savebtn_Click(object sender, EventArgs e)
        {
            if (prdctidtxtbxtxbx.Text == "" || prdctnametxtbx.Text == "" || typecombobx.Text == "" || qntytxtbx.Text == "")
            {
                MessageBox.Show("Please fill the all blanks", "Alert");
            }
            else
            {

                id = prdctidtxtbxtxbx.Text;
                prdctname = prdctnametxtbx.Text;
                type = typecombobx.SelectedItem.ToString();
                quantity = qntytxtbx.Text;
                manufastrdate = mfdatetime.Value.Date;
                expirydate = expdaetime.Value.Date;




                con.Open();
                string insert = "insert into Product values ('" + id + "','" + prdctname + "','" + type + "','" + quantity + "','" +
                    manufastrdate + "','" + expirydate + "')";
                SqlCommand cmd = new SqlCommand(insert, con);
                cmd.ExecuteNonQuery();

                con.Close();

                MessageBox.Show("successfully saved in Product database","Message");
            }

        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            if (prdctidtxtbxtxbx.Text == "" || prdctnametxtbx.Text == "" || typecombobx.Text == "" || qntytxtbx.Text == "")
            {
                MessageBox.Show("Please fill the all blanks", "Alert");
            }
            else
            {
                id = prdctidtxtbxtxbx.Text;
                prdctname = prdctnametxtbx.Text;
                type = typecombobx.Text;
                quantity = qntytxtbx.Text;
                manufastrdate = mfdatetime.Value.Date;
                expirydate = expdaetime.Value.Date;

                string update = "update Product set Product_name ='" + prdctname + "',Type='" + type + "',Quantity='" +
                 quantity + "',Manufacture_date='" + manufastrdate + "',Expiry_date='" + expirydate + "'where Product_id ='" + id + "'";
                if (MessageBox.Show("Are you going to update the Product data?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                {
                    return;
                }
                else
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand(update, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Succesfully updated","Message");
                    con.Close();

                }
            }
        }

        private void btnsearch_Click(object sender, EventArgs e)
        {
             if (prdctidtxtbxtxbx.Text == "")
            {
                MessageBox.Show("Please fill the ID", "Alert");
            }
            else
            {
                id = prdctidtxtbxtxbx.Text;
                string search = "Select *from Product  where Product_id='" + id + "'";
                SqlCommand cmd = new SqlCommand(search, con);

                con.Open();
                SqlDataReader r = cmd.ExecuteReader();
                if (r.Read())
                {
                    prdctnametxtbx.Text = r["Product_name"].ToString();
                    typecombobx.Text = r["Type"].ToString();
                    qntytxtbx.Text = r["Quantity"].ToString();
                    mfdatetime.Text = r["Manufacture_date"].ToString();
                    expdaetime.Text = r["Expiry_date"].ToString();

                    con.Close();
                }
                else
                {
                    MessageBox.Show("Invalid ID", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
            }
        
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            if (prdctidtxtbxtxbx.Text == "")
            {
                MessageBox.Show("Please fill the ID", "Alert");
            }
            else
            {
                id = prdctidtxtbxtxbx.Text;
                con.Open();
                string delete = "delete from Product where Product_id='" + id + "'";
                if (MessageBox.Show("Are you sure to delete data?", "confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                {
                    return;
                }
                else
                {
                    SqlCommand cmd = new SqlCommand(delete, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Successfully Deleted","Message");
                }
                con.Close();
            }
        }

        private void Clearbtn_Click(object sender, EventArgs e)
        {
            prdctidtxtbxtxbx.Clear();
            prdctnametxtbx.Clear();
            typecombobx.ResetText();
            qntytxtbx.Clear();
            mfdatetime.ResetText();
            expdaetime.ResetText();
        }

        private void btnrefresh_Click(object sender, EventArgs e)
        {
            filldata();
        }

        private void dataGridView1_DoubleClick(object sender, EventArgs e)
        {
            prdctidtxtbxtxbx.Text=dataGridView1.CurrentRow.Cells[0].Value.ToString();
            prdctnametxtbx.Text=dataGridView1.CurrentRow.Cells[1].Value.ToString();
            typecombobx.Text=dataGridView1.CurrentRow.Cells[2].Value.ToString();
            qntytxtbx.Text=dataGridView1.CurrentRow.Cells[3].Value.ToString();
            mfdatetime.Text=dataGridView1.CurrentRow.Cells[4].Value.ToString();
            expdaetime.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
        }
    }
}
